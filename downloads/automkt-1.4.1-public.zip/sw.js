/* Service worker: quét tài khoản, quét nhóm, soạn thử và hàng đợi đăng bài.
   Hàng đợi không dựa vào setTimeout dài: trạng thái nằm ở chrome.storage.local, khoảng nghỉ giữa hai nơi
   do chrome.alarms đánh thức. Trong lúc thao tác một nơi, các lệnh gọi API liên tục giữ worker thức. */

import { idb } from "./db.js";
import { EDITION } from "./edition.js";

const HOME = "https://www.facebook.com/";
const JOINS = "https://www.facebook.com/groups/joins/";
const THREADS = "https://www.threads.com/";
const ALARM = "amkt-next";
const HELD_MAX = 5;  // số bài của một lượt cùng nằm chờ duyệt trong một nhóm thì tạm nghỉ nhóm đó tới khi được duyệt bớt

const sleep = ms => new Promise(r => setTimeout(r, ms));
/* Nghỉ ngẫu nhiên giữa các thao tác cho giống người dùng thật */
const pause = (lo = 0.6, hi = 1.6) => sleep((lo + Math.random() * (hi - lo)) * 1000);
const get = async key => (await chrome.storage.local.get(key))[key];
const set = obj => chrome.storage.local.set(obj);
const clock = () => new Date().toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit" });

/** Facebook chặn hoặc bắt xác minh tài khoản. */
class Blocked extends Error {}
/** Nhóm có bài đang chờ duyệt, bị từ chối hoặc bị gỡ: bỏ qua nhóm này, các nơi khác vẫn chạy.
 *  soft = true: chỉ bỏ qua lượt này (đang đủ bài chờ duyệt), lượt sau vào xem lại; không thì dừng nhóm tới hết lượt đăng. */
class Warned extends Error {}

/* ---------- cửa sổ làm việc ---------- */
async function workTab(url) {
  const { work } = await chrome.storage.session.get("work");
  let tab = work && await chrome.tabs.get(work).catch(() => null);
  if (tab) {
    // Cửa sổ phải hiện ra thì Facebook mới vẽ khung soạn bài và mới chụp được ảnh
    const win = await chrome.windows.get(tab.windowId);
    await chrome.windows.update(tab.windowId, win.state === "minimized" ? { state: "normal", focused: true } : { focused: true });
    await chrome.tabs.update(tab.id, { url, active: true });
  } else {
    const win = await chrome.windows.create({ url, focused: true, width: 1280, height: 900 });
    tab = win.tabs[0];
    await chrome.storage.session.set({ work: tab.id });
  }
  await sleep(800);
  for (let i = 0; i < 50; i++) {
    if ((await chrome.tabs.get(tab.id)).status === "complete") break;
    await sleep(500);
  }
  return tab.id;
}

/* Gọi một hàm của page.js trong tab; trang vừa tải lại thì nạp page.js trước */
async function call(tabId, fn, ...args) {
  const run = () => chrome.scripting.executeScript({
    target: { tabId },
    func: (fn, args) => window.__amkt
      ? Promise.resolve().then(() => window.__amkt[fn](...args)).then(v => ({ v }), e => ({ e: String(e?.message || e) }))
      : { missing: true },
    args: [fn, args],
  });
  let [r] = await run();
  if (r?.result?.missing) {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["page.js"] });
    [r] = await run();
  }
  if (r?.result?.e) throw new Error(r.result.e);
  return r?.result?.v;
}

async function waitFor(tabId, fn, args, timeout, every = 700) {
  for (const end = Date.now() + timeout; Date.now() < end; await sleep(every)) {
    const v = await call(tabId, fn, ...args).catch(() => null);  // trang đang chuyển thì thử lại
    if (v) return v;
  }
  return null;
}

async function checkBlocked(tabId) {
  const { url = "" } = await chrome.tabs.get(tabId);
  if (url.includes("/checkpoint") || url.includes("/login"))
    throw new Blocked("Facebook đang bắt đăng nhập lại hoặc xác minh tài khoản. Xử lý trong trình duyệt rồi chạy lại.");
  const hit = await call(tabId, "blocked");
  if (hit) throw new Blocked(`Facebook báo hạn chế tài khoản ("${hit}…"). Đã dừng, nên nghỉ đăng nhóm ít nhất một ngày.`);
}

/* Chụp cửa sổ làm việc. Chrome chỉ cho chụp khi người dùng đã cấp quyền "mọi trang" (tuỳ chọn); chưa cấp thì bỏ qua. */
async function shot(tabId, key) {
  try {
    if (!await chrome.permissions.contains({ origins: ["<all_urls>"] })) return null;
    const { windowId } = await chrome.tabs.get(tabId);
    const url = await chrome.tabs.captureVisibleTab(windowId, { format: "jpeg", quality: 75 });
    await idb.put("shots", { id: key, url });
    return key;
  } catch {
    return null;
  }
}

/* ---------- file đính kèm ---------- */
function b64(u8) {
  let s = "";
  for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
  return btoa(s);
}

/* Tham số executeScript chỉ nhận JSON, nên file đi sang trang theo từng khúc base64 */
async function sendFiles(tabId, files) {
  const CHUNK = 3 * 1024 * 1024;
  await call(tabId, "filesReset");
  for (const f of files) {
    for (let at = 0; at < f.blob.size; at += CHUNK)
      await call(tabId, "filesPush", f.id, b64(new Uint8Array(await f.blob.slice(at, at + CHUNK).arrayBuffer())));
    await call(tabId, "filesDone", f.id, f.name, f.type);
  }
}

/* ---------- soạn và đăng một nơi ---------- */
const NO_TRIGGER = {
  group: "Không thấy ô soạn bài trong nhóm (nhóm có thể đã tắt quyền đăng).",
  feed: "Không thấy ô soạn bài ở trang chủ Facebook.",
  th: "Không thấy ô soạn bài trên Threads (chưa đăng nhập Threads trong trình duyệt này?).",
};

/** it: {kind: group | feed | th, url, name, text, files, label}; files là các id file của riêng bài đó. dry=true: soạn xong chụp ảnh rồi bỏ bài, không đăng.
 *  Trả về {name, status: "da-dang" | "cho-duyet" | "soan-thu", shot, note}. */
async function postItem(it, fileIds, dry, shotKey, watch) {
  const { kind } = it, fb = kind !== "th";
  const files = (await Promise.all(fileIds.map(id => idb.get("files", id)))).filter(Boolean);
  if (files.length < fileIds.length) throw new Error("Có file đính kèm đã bị xoá khỏi extension. Chọn lại file rồi chạy lại.");
  const url = kind === "group" ? it.url : fb ? HOME : THREADS;

  if (kind === "group" && watch) await checkGroup(url, watch);  // chỉ khi lượt này đăng nhiều bài vào nhóm
  const tabId = await workTab(url);
  await pause(2.5, 4);
  if (fb) {
    await checkBlocked(tabId);
    await call(tabId, "dismiss");
  } else if (((await chrome.tabs.get(tabId)).url || "").includes("/login")) {
    throw new Error("Chưa đăng nhập Threads trong trình duyệt này.");
  }
  let name = it.name;
  if (kind === "group") {
    const title = ((await chrome.tabs.get(tabId)).title || "").replace(/^\(\d+\+?\)\s*/, "").split(" | ")[0].trim();
    if (title && !/^facebook$/i.test(title)) name = title;
  }

  if (!await waitFor(tabId, "hasTrigger", [kind], fb ? 15_000 : 20_000)) {
    if (kind === "group" && await call(tabId, "canJoin")) throw new Error("Tài khoản này chưa là thành viên của nhóm.");
    throw new Error(`${NO_TRIGGER[kind]} Các nút đang thấy: ${await call(tabId, "buttons").catch(() => "không đọc được")}`);
  }
  // nhóm có thể đang giữ sẵn bài cũ chờ duyệt, nên so số trước và sau khi đăng
  const waiting = kind === "group" ? await call(tabId, "pending") : 0;
  const seen = watch && kind === "group" ? (watch[url.replace(/\/+$/, "") + "/"] ||= {}) : null;
  if (seen) seen.pending ??= waiting;  // số bài chờ duyệt có sẵn lúc lượt này mới vào nhóm
  if (seen && waiting - seen.pending >= HELD_MAX) {  // tạm nghỉ: quản trị viên duyệt bớt thì lượt sau đăng tiếp
    await warnGroup(url, `${waiting - seen.pending} bài đăng trong lượt này đang chờ quản trị viên duyệt, tạm nghỉ`);
    throw Object.assign(new Warned(`Nhóm đang giữ ${waiting - seen.pending} bài của lượt này chờ duyệt nên bỏ qua lần đăng này. Khi được duyệt bớt, các lần sau sẽ đăng tiếp.`), { soft: true });
  }

  await pause();
  await call(tabId, "open", kind);
  if (!await waitFor(tabId, "hasDialog", [kind], 20_000)) throw new Error("Đã bấm ô soạn bài nhưng khung soạn không mở ra.");
  await pause();

  let typed = null;
  if (it.text) typed = await call(tabId, "type", kind, it.text);
  await pause();

  if (files.length) {
    await sendFiles(tabId, files);
    await call(tabId, "attach", kind);
    await sleep(2500 + 1500 * files.length);
  }
  const video = files.some(f => f.type.startsWith("video/"));
  let state;
  for (const end = Date.now() + (video ? 480_000 : files.length ? 90_000 : 10_000); ; await sleep(1000)) {  // chờ tải xong: nút Đăng hết bị khóa
    state = await call(tabId, "publishState", kind);
    if ((state.found && !state.disabled) || Date.now() > end) break;
  }
  await pause(1, 2);
  const ai = await call(tabId, "aiLabelOff", kind);  // không gắn nhãn AI: thấy công tắc đang bật thì tắt
  const aud = kind === "feed" ? await call(tabId, "audiencePublic", kind) : null;  // trang cá nhân luôn đăng Công khai

  if (dry) {
    const sum = await call(tabId, "summary", kind);
    const note = [`khung soạn có ${sum.chars} ký tự`, typed && `điền chữ bằng cách ${typed.how}`,
                  typed && typed.got !== typed.want && `đối chiếu ${typed.got}/${typed.want} chữ, nên xem lại ảnh chụp`,
                  files.length && `${files.length} file đính kèm`,
                  { "da-tat": "nhãn AI đang bật, đã tắt", "dang-tat": "nhãn AI đang tắt", "con-bat": "nhãn AI đang bật, KHÔNG tắt được",
                    "khong-thay": "khung soạn không có công tắc nhãn AI" }[ai],
                  aud && { san: "đối tượng: Công khai", "da-doi": "đã đổi đối tượng sang Công khai", "khong-doi": "KHÔNG đổi được sang Công khai",
                           "khong-thay": "không thấy nút chọn đối tượng" }[aud], `nút Đăng ${sum.ready ? "đã mở" : "còn khóa"}`].filter(Boolean).join(" · ");
    const preview = await shot(tabId, shotKey);
    await call(tabId, "cancel", kind);
    if (fb) await chrome.tabs.update(tabId, { url: HOME });  // rời trang để chắc chắn không còn bài nháp
    return { name, status: "soan-thu", shot: preview, note };
  }

  if (ai === "con-bat") throw new Error("Nhãn AI đang bật trong khung soạn và không tắt được, đã dừng trước khi đăng.");
  if (aud === "khong-doi" || aud === "khong-thay") throw new Error("Không chuyển được bài sang chế độ Công khai, đã dừng trước khi đăng.");
  if (!state.found || state.disabled) throw new Error("Nút Đăng đang bị khóa (có thể file chưa tải xong hoặc bài chưa có nội dung).");
  await call(tabId, "publish", kind);
  if (!await waitFor(tabId, "dialogGone", [kind], fb ? 120_000 : 90_000, 1000)) {
    if (fb) await checkBlocked(tabId);
    await shot(tabId, shotKey);
    throw new Error("Đã bấm Đăng nhưng khung soạn bài không đóng. Mở cửa sổ làm việc kiểm tra lại.");
  }
  await pause(3, 5);
  let status = "da-dang", held = 0;  // held: số bài của lượt này đang cùng nằm chờ duyệt trong nhóm
  if (fb) await checkBlocked(tabId);
  if (kind === "group") {
    await workTab(it.url);
    await pause(3, 4.5);
    const now = await call(tabId, "pending").catch(() => 0);
    if (now > waiting) {
      status = "cho-duyet";
      held = seen ? now - seen.pending : 1;
      await warnGroup(url, `${held} bài đăng trong lượt này đang chờ quản trị viên duyệt`);
    }
  }
  if (fb && status === "da-dang") {  // đưa đúng bài vừa đăng lên đầu màn hình để chụp; bài chờ duyệt thì dải thông báo nằm ngay đầu trang
    let seen = false;
    for (let i = 0; i < 4 && !seen; i++) {
      seen = await call(tabId, "showPost", it.text || "").catch(() => false);
      if (!seen) { await call(tabId, "scroll", 500).catch(() => {}); await sleep(1200); }
    }
    await sleep(1200);
  }
  return { name, status, held, shot: await shot(tabId, shotKey), note: null };
}

/* ---------- chỉ một việc chạy mỗi lúc ---------- */
let working = false;
async function exclusive(fn) {
  if (working) throw new Error("Extension đang bận thao tác khác. Chờ xong đã.");
  working = true;
  const awake = setInterval(() => chrome.runtime.getPlatformInfo(), 20_000);  // giữ service worker thức trong lúc thao tác
  try {
    return await fn();
  } finally {
    clearInterval(awake);
    working = false;
  }
}

async function idle() {
  if ((await get("job"))?.status === "running") throw new Error("Đang có một lượt đăng chạy. Chờ xong hoặc bấm Dừng trước.");
}

/* ---------- quét tài khoản và nhóm ---------- */
async function scanAccount() {
  const cookie = (url, name) => chrome.cookies.get({ url, name }).catch(() => null);
  const can = origin => chrome.permissions.contains({ origins: [origin] });
  const uid = (await cookie(HOME, "c_user"))?.value || "";
  const account = {
    fb: { in: !!uid, uid, name: "" },
    th: { in: !!await cookie(THREADS, "sessionid") },
    // Instagram / TikTok chỉ đọc được khi người dùng đã cấp thêm quyền; chưa cấp thì để null (chưa kiểm tra)
    ig: await can("https://*.instagram.com/*") ? { in: !!await cookie("https://www.instagram.com/", "sessionid") } : null,
    tt: await can("https://*.tiktok.com/*") ? { in: !!await cookie("https://www.tiktok.com/", "sessionid") } : null,
    at: clock(),
  };
  if (uid) {
    const old = await get("account");
    if (old?.fb?.uid === uid) account.fb.name = old.fb.name || "";
    try {  // Facebook nhúng tên tài khoản đang dùng vào mã trang (CurrentUserInitialData), ổn định hơn dò giao diện
      const html = await (await fetch(HOME, { credentials: "include", headers: { accept: "text/html" } })).text();
      const m = html.match(/"NAME":("(?:[^"\\]|\\.)*")/);
      if (m) account.fb.name = JSON.parse(m[1]);
    } catch { /* không đọc được tên thì lượt quét nhóm sẽ đọc từ trang */ }
  }
  await set({ account });
  return account;
}

async function scanGroups() {
  const account = await scanAccount();
  if (!account.fb.in) throw new Error("Trình duyệt này chưa đăng nhập Facebook.");
  const tabId = await workTab(JOINS);
  await pause(2.5, 4);
  await checkBlocked(tabId);
  await call(tabId, "dismiss");
  let found = [], same = 0;
  for (let i = 0; i < 40; i++) {  // trang tải thêm nhóm khi cuộn xuống; dừng khi cuộn 3 lần không ra nhóm mới
    const now = await call(tabId, "joined");
    same = now.length === found.length ? same + 1 : 0;
    found = now;
    if (same >= 3 || found.length >= 300) break;
    await call(tabId, "scroll", 2400);
    await pause(1, 1.8);
  }
  await call(tabId, "scroll", 0);
  if (!account.fb.name) {
    account.fb.name = await call(tabId, "name").catch(() => "") || "";
    await set({ account });
  }
  // Gộp vào danh sách của nick này; nhóm quét về không tick sẵn
  const all = await get("groups") || {}, list = all[account.fb.uid] || [];
  let fresh = 0;
  for (const g of found.slice(0, 300)) {
    const url = `https://www.facebook.com/groups/${g.id}/`, old = list.find(x => x.url === url);
    if (old) old.name = g.name || old.name;
    else { list.push({ url, name: g.name, on: false }); fresh++; }
  }
  all[account.fb.uid] = list;
  await set({ groups: all });
  return { found: found.length, fresh };
}

/* Nhớ bài nào (pk) đã lên nơi nào (where), để lần bấm Đăng sau không đăng trùng. Giữ 60 ngày, mỗi nơi 40 bài gần nhất. */
async function remember(it) {
  if (!it.pk || !it.where) return;
  const posted = await get("posted") || {}, now = Date.now();
  for (const k in posted) {
    posted[k] = posted[k].filter(r => now - r.at < 60 * 86400_000);
    if (!posted[k].length) delete posted[k];
  }
  posted[it.where] = [{ pk: it.pk, at: now }, ...(posted[it.where] || []).filter(r => r.pk !== it.pk)].slice(0, 40);
  await set({ posted });
}

const sameGroup = (a, b) => a.replace(/\/+$/, "") === b.replace(/\/+$/, "");

/* Gắn cảnh báo cho nhóm (text) hoặc xoá cảnh báo (text rỗng). Cảnh báo chỉ nói về lượt đăng gần nhất: lượt mới bắt đầu là xoá. */
async function warnGroup(url, text) {
  const all = await get("groups") || {};
  for (const list of Object.values(all))
    for (const g of list)
      if (sameGroup(g.url, url)) {
        if (text) g.warn = { text, at: new Date().toLocaleDateString("vi-VN") };
        else delete g.warn;
        delete g.seen;
      }
  await set({ groups: all });
}

/* Chỉ tính trong một lượt đăng: lần đầu vào nhóm ghi lại số bài đang nằm ở mục "Đã từ chối" và "Đã gỡ" (Nội dung của bạn);
   các lần sau trong cùng lượt mà số đó tăng thì bài mình vừa đăng đã bị từ chối / gỡ, dừng đăng tiếp vào nhóm này.
   watch: {[url]: {declined, removed}} nằm trong job. Không đọc được trang thì coi như không có gì. */
async function checkGroup(url, watch) {
  const base = url.replace(/\/+$/, "") + "/";
  const count = async page => {
    const tabId = await workTab(base + page);
    for (const end = Date.now() + 12_000; Date.now() < end; await sleep(800)) {
      const n = await call(tabId, "mine").catch(() => -1);
      if (n >= 0) return n;
    }
    return 0;
  };
  const declined = await count("my_declined_content");
  await pause(1, 2);
  const removed = await count("my_removed_content");
  const was = watch[base];
  if (!was) { watch[base] = { declined, removed }; return; }
  const news = [declined > was.declined && `${declined - was.declined} bài bị quản trị viên từ chối`,
                removed > was.removed && `${removed - was.removed} bài bị gỡ`].filter(Boolean).join(", ");
  if (!news) return;
  await warnGroup(url, `${news} trong lượt đăng này`);
  throw new Warned(`Trong lượt này nhóm đã có ${news}. Dừng đăng tiếp vào nhóm này.`);
}

async function setGroupName(url, name) {
  const all = await get("groups") || {};
  let changed = false;
  for (const list of Object.values(all))
    for (const g of list)
      if (g.url === url && name && g.name !== name) { g.name = name; changed = true; }
  if (changed) await set({ groups: all });
}

/* ---------- hàng đợi ---------- */
async function finish(job, stopped) {
  for (const it of job.items) if (it.status === "cho" || it.status === "dang-chay") it.status = "bo-qua";
  if (job.status === "running") job.status = stopped ? "stopped" : "done";
  job.next_at = null;
  await chrome.alarms.clear(ALARM);
  // Lịch sử: 30 lượt gần nhất, bỏ nội dung bài và ảnh chụp cho nhẹ
  const past = { started: job.started, status: job.status, note: job.note,
                 items: job.items.map(({ name, label, kind, status, error, at }) => ({ name, label, kind, status, error, at })) };
  await set({ job, stop: false, history: [past, ...(await get("history") || [])].slice(0, 30) });
}

/* Đăng một nơi rồi hẹn chuông cho nơi kế tiếp */
async function step() {
  if (working) return;
  await exclusive(async () => {
    const job = await get("job");
    if (!job || job.status !== "running") return;
    if (job.next_at && Date.now() < job.next_at - 500) return;  // chuông cũ hoặc hẹn giờ trùng: chưa tới lượt
    const i = job.items.findIndex(x => x.status === "cho");
    if (i < 0 || await get("stop")) return finish(job, i >= 0);
    const it = job.items[i];
    const sameG = x => x.kind === "group" && it.kind === "group" && sameGroup(x.url, it.url);
    job.halt ||= {}; job.watch ||= {};
    it.status = "dang-chay";
    job.next_at = null;
    await set({ job });
    try {
      const res = await postItem(it, it.files || job.files, false, `job-${i}`, job.items.filter(sameG).length > 1 ? job.watch : null);
      Object.assign(it, { status: res.status, shot: res.shot, name: res.name || it.name });
      await remember(it);
      if (it.kind === "group") await setGroupName(it.url, res.name);
    } catch (e) {
      Object.assign(it, { status: e instanceof Warned ? "canh-bao" : "loi", error: String(e.message || e).split("\n")[0] });
      if (e instanceof Warned && !e.soft) job.halt[it.url] = it.error;
      if (e instanceof Blocked) Object.assign(job, { status: "blocked", note: e.message });
    }
    it.at = clock();
    // Nhóm giữ bài chờ duyệt / từ chối / gỡ bài trong lượt này: các bài còn lại của nhóm đó bỏ qua luôn, không mở trang nữa
    if (job.halt[it.url]) for (const x of job.items) if (x.status === "cho" && sameG(x)) Object.assign(x, { status: "canh-bao", error: job.halt[it.url], at: clock() });
    const stop = await get("stop"), left = job.items.some(x => x.status === "cho");
    if (job.status !== "running" || stop || !left) return finish(job, stop && left);
    // Bài kế tiếp vẫn ở nơi vừa đăng (nhiều bài một nhóm) thì nghỉ theo gapIn, sang nơi khác thì theo gap; đều tính bằng giây
    const next = job.items.find(x => x.status === "cho");
    // sang vòng lặp mới thì nghỉ theo gapRep (khoảng cách giữa hai lần đăng lặp)
    const [lo, hi] = job.gapRep && (next.round || 0) !== (it.round || 0) ? job.gapRep
      : job.gapIn && next.kind === it.kind && next.url === it.url ? job.gapIn : job.gap;
    // Có khung giờ: mỗi lượt có giờ chạy riêng chia đều trong khung, lệch ngẫu nhiên tối đa 15% khoảng cách (không quá 1 phút).
    // Lượt trước chạy lố giờ thì lượt sau chạy ngay.
    job.next_at = job.slot
      ? Math.max(Date.now() + 1000, job.slot.start + job.items.indexOf(next) * job.slot.step + Math.random() * Math.min(60_000, job.slot.step * 0.15))
      : Date.now() + (lo + Math.random() * (hi - lo)) * 1000;
    await set({ job });
    await chrome.alarms.create(ALARM, { when: job.next_at });
    // Chrome có thể kéo chuông dưới 30 giây lên thành 30 giây: nghỉ ngắn thì tự hẹn giờ, chuông để dự phòng
    if (job.next_at - Date.now() < 30_000) setTimeout(step, job.next_at - Date.now());
  }).catch(e => console.error(e));
}

chrome.alarms.onAlarm.addListener(a => { if (a.name === ALARM) step(); });

/* Service worker vừa thức dậy: lượt đăng dở dang thì nối lại. Nơi đang đăng dở lúc bị ngắt không thử lại, tránh đăng hai lần. */
async function recover() {
  const job = await get("job");
  if (working || !job || job.status !== "running") return;
  const cut = job.items.find(x => x.status === "dang-chay");
  if (cut) {
    Object.assign(cut, { status: "loi", at: clock(), error: "Bị ngắt giữa chừng (trình duyệt tắt hoặc extension nạp lại). Mở nơi này kiểm tra xem bài đã lên chưa." });
    if (!job.items.some(x => x.status === "cho")) return finish(job, false);
    job.next_at = Date.now() + job.gap[0] * 1000;
    await set({ job });
  }
  if (cut || !await chrome.alarms.get(ALARM)) await chrome.alarms.create(ALARM, { when: Math.max(job.next_at || 0, Date.now() + 1000) });
}
recover();

/* ---------- lệnh từ trang giao diện ---------- */
const COMMANDS = {
  scan: () => scanAccount(),
  groups: async () => { await idle(); return exclusive(scanGroups); },
  try: async ({ item, files }) => {
    await idle();
    await set({ tried: null });
    return exclusive(async () => {
      const res = await postItem(item, files, true, "try");
      await set({ tried: { ...res, at: clock() } });
    });
  },
  run: async ({ items, files, gap, gapIn, gapRep, slot }) => {
    await idle();
    if (working) throw new Error("Extension đang bận thao tác khác. Chờ xong đã.");
    if (new Set(items.filter(x => x.kind === "group").map(x => x.url.replace(/\/+$/, ""))).size > EDITION.maxGroups)
      throw new Error(`Mỗi lượt tối đa ${EDITION.maxGroups} nhóm.`);
    if (!EDITION.repeat && items.some(x => x.round > 0)) throw new Error("Phiên bản này không có đăng lặp lại.");
    await idb.clear("shots");
    for (const url of new Set(items.filter(x => x.kind === "group").map(x => x.url))) await warnGroup(url, "");  // cảnh báo chỉ tính trong lượt
    await set({
      stop: false, tried: null,
      job: { status: "running", started: Date.now(), next_at: slot && slot.start > Date.now() ? slot.start : null, gap, gapIn, gapRep, slot: slot || null,
             note: null, files, watch: {}, halt: {},
             items: items.map(it => ({ ...it, status: "cho", error: null, shot: null, at: null })) },
    });
    if (slot && slot.start > Date.now()) await chrome.alarms.create(ALARM, { when: slot.start });  // chưa tới khung giờ: chuông đánh thức đúng lúc
    step();
  },
  stop: async () => {
    await set({ stop: true });
    const job = await get("job");
    if (!working && job?.status === "running") await finish(job, true);  // đang nghỉ giữa hai nơi thì dừng ngay
  },
};

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (sender.id !== chrome.runtime.id || !COMMANDS[msg?.cmd]) return;
  COMMANDS[msg.cmd](msg).then(data => reply({ ok: true, data }), e => reply({ ok: false, error: String(e.message || e) }));
  return true;
});
