/* Trang giao diện. Trạng thái dùng chung (tài khoản, nhóm, lượt đăng, lịch sử) nằm ở chrome.storage.local do service worker ghi;
   trang này chỉ đọc lại khi có thay đổi. File đính kèm nằm ở IndexedDB. */

import { variants, normalize } from "./variants.js";
import { idb } from "./db.js";
import { EDITION } from "./edition.js";

const MAX_GROUPS = EDITION.maxGroups, MAX_POSTS = 20, MAX_REP = EDITION.repeat ? 20 : 1, TH_MAX = 500, TH_FILES = 20;
const ALL_URLS = { origins: ["<all_urls>"] };
const MORE_SITES = { origins: ["https://*.instagram.com/*", "https://*.tiktok.com/*"] };
const STATUS = { "cho": ["Chờ", ""], "dang-chay": ["Đang đăng", "run"], "da-dang": ["Đã đăng", "ok"],
                 "cho-duyet": ["Chờ admin duyệt", "warn"], "loi": ["Lỗi", "bad"], "canh-bao": ["Bỏ qua, có cảnh báo", "warn"], "bo-qua": ["Chưa đăng", ""] };
const SITES = { fb: ["Facebook", "facebook.com"], th: ["Threads", "threads.com"], ig: ["Instagram", "instagram.com"], tt: ["TikTok", "tiktok.com"] };
const VIEWS = {
  "soan": ["Soạn bài mới", "Chuẩn bị nội dung và chọn nơi đăng"],
  "tong-quan": ["Tổng quan", "Tình trạng tài khoản và lượt đăng gần nhất"],
  "tai-khoan": ["Tài khoản", "Các tài khoản đang đăng nhập trong trình duyệt này"],
  "lich-su": ["Lịch sử", "Các lượt đăng đã chạy trên máy này"],
  "cai-dat": ["Cài đặt", "Quyền của extension và dữ liệu lưu trên máy"],
};
const svg = body => `<svg class="pi" viewBox="0 0 24 24" aria-hidden="true">${body}</svg>`;
const ICON = {
  fb: svg('<rect width="24" height="24" rx="6" fill="#1877f2"/><path fill="#fff" d="M15.6 8.3h-1.5c-.6 0-.9.3-.9 1V11h2.3l-.3 2.4h-2V20h-2.5v-6.6H8.8V11h1.9V9.2c0-1.9 1.1-3 2.9-3 .8 0 1.5.1 2 .1z"/>'),
  th: svg('<rect width="24" height="24" rx="6" fill="#000"/><text x="12" y="17" text-anchor="middle" font-size="15" font-weight="700" fill="#fff" font-family="system-ui,sans-serif">@</text>'),
  ig: svg('<defs><linearGradient id="igg" x1="0" y1="1" x2="1" y2="0"><stop offset="0" stop-color="#f9ce34"/><stop offset=".5" stop-color="#ee2a7b"/><stop offset="1" stop-color="#6228d7"/></linearGradient></defs><rect width="24" height="24" rx="6" fill="url(#igg)"/><rect x="6" y="6" width="12" height="12" rx="3.5" fill="none" stroke="#fff" stroke-width="1.6"/><circle cx="12" cy="12" r="2.8" fill="none" stroke="#fff" stroke-width="1.6"/><circle cx="15.6" cy="8.4" r=".9" fill="#fff"/>'),
  tt: svg('<rect width="24" height="24" rx="6" fill="#000"/><path fill="#fff" d="M14.5 5h-2.2v9.3a1.9 1.9 0 1 1-1.9-1.9c.2 0 .4 0 .6.1v-2.3a4.2 4.2 0 1 0 3.5 4.1V9.6c.9.6 1.9.9 3 .9V8.3c-1.6 0-3-1.4-3-3.3z"/>'),
};

/* Cùng một trang chạy ở hai chỗ: tab đầy đủ, và cửa sổ nhỏ bật ra khi bấm icon extension (app.html?popup=1) */
const POPUP = new URLSearchParams(location.search).has("popup");

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const SPIN = '<span class="spin" aria-hidden="true"></span>';

let st = { account: null, groups: {}, job: null, tried: null, history: [], posted: {} };
/* posts: mỗi bài có các bản viết, nội dung Threads và file riêng (file ở IndexedDB, trường `post` = id bài) */
let form = { dest: { groups: true, feed: false, th: false }, posts: [{ id: 0, texts: [""], thText: "" }], touch: true,
             outLo: 1, outHi: 2, minLo: 1, minHi: 2, rep: 1, repLo: 30, repHi: 40, win: false, winFrom: "09:00", winTo: "12:00",  // phút: nghỉ khi sang nơi khác / giữa hai bài trong cùng một nơi
             seed: Date.now() % 1e9 };
let ui = { busy: null, err: null, post: 0, files: [], urls: new Map(), tab: "main", pvTab: "fb", pvI: 0, gshow: "all", canMore: false, canShot: false };

const send = (cmd, extra = {}) => chrome.runtime.sendMessage({ cmd, ...extra })
  .catch(e => ({ ok: false, error: `Extension không phản hồi: ${e.message}` }));
const body = document.body;
body.classList.toggle("popup", POPUP);
let saveTimer;
const saveForm = () => { clearTimeout(saveTimer); saveTimer = setTimeout(() => chrome.storage.local.set({ form }), 400); };
function toast(msg) {
  const t = $("#toast");
  t.textContent = msg;
  t.classList.add("on");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => t.classList.remove("on"), 3200);
}

/* ---------- dữ liệu suy ra ---------- */
const view = () => VIEWS[location.hash.slice(1)] ? location.hash.slice(1) : "soan";
const running = () => st.job?.status === "running";
const gkey = () => st.account?.fb?.uid || "_";
const glist = () => st.groups[gkey()] || [];
const gName = g => g.name || decodeURIComponent(g.url.split("/groups/")[1].replace(/\/$/, ""));
const saveGroups = list => { st.groups[gkey()] = list; return chrome.storage.local.set({ groups: st.groups }); };
const initials = name => (name || "?").trim().split(/\s+/).slice(0, 2).map(w => w[0]).join("").toUpperCase();
const fileUrl = f => { if (!ui.urls.has(f.id)) ui.urls.set(f.id, URL.createObjectURL(f.blob)); return ui.urls.get(f.id); };

const cur = () => form.posts[ui.post] || form.posts[0];
const pfiles = post => ui.files.filter(f => (f.post ?? 0) === post.id);
const many = () => form.posts.length > 1;
/* Số lần đăng lặp mỗi bài lên mỗi nơi trong một lượt */
/* Khung giờ đăng cho n lượt: giờ bắt đầu (ms) và khoảng cách đều giữa hai lượt (ms). Lượt k chạy lúc start + k * step, nên lượt cuối
   vẫn nằm trong khung. Đang ở giữa khung thì tính từ bây giờ; đã qua khung thì dời sang ngày mai; giờ kết thúc nhỏ hơn giờ bắt đầu là qua đêm. */
function slot(n) {
  if (!form.win || !n) return null;
  const at = (hm, base) => { const [h, m] = hm.split(":").map(Number), d = new Date(base); d.setHours(h || 0, m || 0, 0, 0); return d.getTime(); };
  const now = Date.now(), DAY = 86400_000;
  let a = at(form.winFrom, now), b = at(form.winTo, now);
  if (b <= a) b += DAY;
  if (now >= b) { a += DAY; b += DAY; }
  const start = Math.max(a, now);
  return { start, end: b, step: (b - start) / n, later: start > now, tomorrow: new Date(start).getDate() !== new Date(now).getDate() };
}
const secs = ms => ms >= 90_000 ? `${Math.round(ms / 6000) / 10} phút`.replace(".", ",") : `${Math.max(1, Math.round(ms / 1000))} giây`;
const hhmm = ms => new Date(ms).toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit" });
const repGap = () => form.repLo === form.repHi ? `${form.repLo}` : `${form.repLo}–${form.repHi}`;
const rep = () => Math.min(MAX_REP, Math.max(1, Math.round(form.rep) || 1));
const iname = x => x.label ? `${x.name} · ${x.label}` : x.name;

/* Các nơi sẽ đăng, theo đúng thứ tự chạy: nhóm, trang cá nhân, Threads */
function places() {
  const out = [];
  if (form.dest.groups) for (const g of glist()) if (g.on) out.push({ kind: "group", url: g.url, name: gName(g) });
  if (form.dest.feed) out.push({ kind: "feed", name: "Trang cá nhân Facebook" });
  if (form.dest.th) out.push({ kind: "th", name: "Threads" });
  return out;
}

/* Các lượt đăng theo đúng thứ tự chạy: từng nơi, trong mỗi nơi lần lượt từng bài. Xem trước và chạy thật cùng gọi
   hàm này với cùng seed nên ra cùng kết quả. */
/* Dấu nhận ra "cùng một bài": các bản viết gốc, nội dung Threads và file đính kèm (tên + dung lượng). Sửa một chữ là thành bài khác. */
function postKey(post) {
  const s = JSON.stringify([post.texts.map(t => t.trim()).filter(Boolean), post.thText.trim(), pfiles(post).map(f => [f.name, f.size])]);
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = (h * 33 ^ s.charCodeAt(i)) >>> 0;
  return `${h.toString(36)}-${s.length}`;
}
const whereKey = x => `${gkey()}|${x.kind}|${(x.url || "").replace(/\/+$/, "")}`;
/* Lượt này đã đăng lên nơi đó rồi thì trả về thời điểm đăng (ms), chưa thì undefined */
const postedAt = x => (st.posted[x.where] || []).find(r => r.pk === x.pk)?.at;

function items() {
  const p = places(), R = rep();
  return Array.from({ length: R }).flatMap((_, r) => {  // mỗi vòng lặp biến tấu theo seed riêng để các lần đăng không giống hệt nhau
    const per = form.posts.map((post, k) => ({ post, pk: postKey(post), v: variants(post.texts, p.length, form.touch, form.seed + k + r * 7919), files: pfiles(post).map(f => f.id) }));
    return p.flatMap((x, i) => per.map(({ post, pk, v, files }, k) => ({
      ...x, label: [many() && `Bài ${k + 1}`, R > 1 && `lần ${r + 1}`].filter(Boolean).join(" · "), files, pk, pi: k, round: r, where: whereKey(x),
      text: x.kind === "th" && post.thText.trim() ? post.thText.trim() : v[i],
    })));
  });
}

/* Lý do chưa bấm đăng được ("" nếu đã đủ) */
function missing() {
  const a = st.account, list = items();
  if (!a) return "Bấm Quét tài khoản để extension biết trình duyệt này đang đăng nhập nick nào.";
  if ((form.dest.groups || form.dest.feed) && !a.fb.in) return "Trình duyệt này chưa đăng nhập Facebook. Đăng nhập rồi bấm Quét lại.";
  if (form.dest.th && !a.th.in) return "Đăng nhập Threads rồi bấm Quét lại, hoặc bỏ chọn Threads.";
  if (!list.length) return form.dest.groups && !form.dest.feed && !form.dest.th ? "Chưa tick nhóm nào." : "Chưa chọn nơi đăng.";
  if (places().filter(x => x.kind === "group").length > MAX_GROUPS) return `Mỗi lượt tối đa ${MAX_GROUPS} nhóm. Bỏ tick bớt.`;
  for (const [k, post] of form.posts.entries()) {
    const which = many() ? `Bài ${k + 1}` : "Bài", n = pfiles(post).length;
    if (!post.texts.some(t => t.trim()) && !n) return many() ? `Bài ${k + 1} chưa có nội dung hay file nào. Soạn tiếp hoặc xoá bài đó.` : "Chưa có nội dung hay file nào.";
    const th = list.find(x => x.kind === "th" && x.pi === k);
    if (th && th.text.length > TH_MAX) return `${which} đăng Threads dài ${th.text.length} ký tự, tối đa ${TH_MAX}. Viết nội dung riêng ở tab Threads.`;
    if (th && !th.text && !n) return `${which} chưa có nội dung cho Threads.`;
    if (th && n > TH_FILES) return `${which}: Threads tối đa ${TH_FILES} file.`;
  }
  return "";
}

/* ---------- vẽ từng khối ---------- */
function renderDests() {
  const a = st.account;
  const picked = glist().filter(g => g.on).length;
  const card = (key, site, label, short) => {
    const need = a && !a[site].in;
    return `<label class="dest ${need && form.dest[key] ? "need" : ""}"><input type="checkbox" data-dest="${key}" ${form.dest[key] ? "checked" : ""}>
      ${ICON[site]}<b class="full-only">${label}</b><b class="pop-only">${short}</b><small>${!a ? "Chưa quét tài khoản" : need ? "Chưa đăng nhập" : "Sẵn sàng"}</small></label>`;
  };
  const out = !a ? [] : [(form.dest.groups || form.dest.feed) && !a.fb.in && "fb", form.dest.th && !a.th.in && "th"].filter(Boolean);
  $("#dest-warn").hidden = !out.length;
  $("#dest-warn").innerHTML = out.map(k => `<span><b>${SITES[k][0]} chưa đăng nhập.</b> <a href="https://www.${SITES[k][1]}/" target="_blank" rel="noopener">Đăng nhập</a></span>`).join("");
  const soon = (site, label) => `<label class="dest off" title="Chưa làm"><input type="checkbox" disabled>${ICON[site]}<b>${label}</b><small>Chưa có</small></label>`;
  $("#dests").innerHTML = card("groups", "fb", "Nhóm Facebook", `Nhóm FB · ${picked}`) + card("feed", "fb", "Trang cá nhân Facebook", "Cá nhân FB") + card("th", "th", "Threads", "Threads")
    + soon("ig", "Instagram") + soon("tt", "TikTok");
}

/* Extension không đăng nhập hộ: nơi nào chưa đăng nhập thì có nút mở trang để người dùng tự đăng nhập */
function renderAcct() {
  const a = st.account, busy = running() || !!ui.busy;
  const row = key => {
    const [label, site] = SITES[key], x = a?.[key];
    const who = key === "fb" && x?.in ? `<b>${esc(x.name || "Đã đăng nhập")}</b><small>Facebook</small>`
      : `<b>${label}</b><small>${!a ? "Chưa quét" : x === null ? "Chưa kiểm tra" : x.in ? "Đang dùng trong trình duyệt này" : "Chưa đăng nhập"}</small>`;
    const side = !a ? "" : x === null ? `<button type="button" class="btn" data-act="more-perm">Kiểm tra</button>`
      : x.in ? '<span class="pill ok">Đã đăng nhập</span>'
      : `<a class="btn ${key === "th" && form.dest.th ? "warn" : ""}" href="https://www.${site}/" target="_blank" rel="noopener">Đăng nhập</a>`;
    return `<div class="arow">${ICON[key]}${key === "fb" && x?.in ? `<span class="avatar">${esc(initials(x.name))}</span>` : ""}<span class="who">${who}</span>${side}</div>`;
  };
  const out = a ? Object.keys(SITES).filter(k => a[k] && !a[k].in).map(k => SITES[k][0]) : [];
  const html = Object.keys(SITES).map(row).join("")
    + (out.length ? `<p class="note"><b>Chưa đăng nhập ${esc(out.join(", "))}.</b> Bấm Đăng nhập để mở trang, tự đăng nhập, rồi bấm Quét lại.</p>` : "")
    + `<p class="hint">${a ? `Quét lúc ${esc(a.at)}. ` : ""}Extension chỉ đọc trạng thái đăng nhập, không đăng nhập hộ.</p>`;
  $$(".acct-slot").forEach(el => el.innerHTML = html);
  $("#me").textContent = a?.fb.in ? initials(a.fb.name) : "?";
  $("#mini").innerHTML = `${ICON.fb}<span class="who"><b>${esc(a?.fb.in ? a.fb.name || "Facebook" : "Facebook")}${a?.fb.in ? ' <i class="dot" aria-hidden="true"></i>' : ""}</b>
    <small>${!a ? "Chưa quét tài khoản" : a.fb.in ? "Đã kết nối" : "Chưa đăng nhập"}</small></span><button type="button" class="btn" data-act="scan"></button>`;
  $$('[data-act="scan"]').forEach(b => {
    b.innerHTML = ui.busy === "scan" ? SPIN + "Đang quét…" : a ? "Quét lại" : "Quét tài khoản";
    b.classList.toggle("primary", !a);
    b.classList.toggle("soft", !!a);
    b.disabled = busy;
  });
}

function renderTabs() {
  $$("[data-tab]").forEach(b => b.setAttribute("aria-selected", b.dataset.tab === ui.tab));
  $("#panel-main").hidden = ui.tab !== "main";
  $("#panel-th").hidden = ui.tab !== "th";
  cur().texts.forEach((t, i) => { const el = $(`#n${i}`); if (el) el.textContent = `${t.trim().length} ký tự`; });
  const tn = cur().thText.trim().length;
  $("#th-n").textContent = `${tn}/${TH_MAX}`;
  $("#th-n").classList.toggle("over", tn > TH_MAX);
}

/* Dải chọn bài: mỗi bài có nội dung và file riêng; các ô soạn bên dưới là của bài đang chọn */
function renderPosts() {
  ui.post = Math.min(ui.post, form.posts.length - 1);
  $("#posts").innerHTML = form.posts.map((p, k) => {
    const n = pfiles(p).length, empty = !p.texts.some(t => t.trim()) && !n;
    return `<button type="button" class="pchip" data-post="${k}" aria-pressed="${k === ui.post}">Bài ${k + 1}<small>${empty ? "trống" : n ? `${n} file` : "chỉ chữ"}</small></button>`;
  }).join("") + `<button type="button" class="btn soft" data-act="post-add" ${form.posts.length >= MAX_POSTS ? "disabled" : ""}>+ Thêm bài</button>`
    + (many() ? `<button type="button" class="link" data-act="post-del">Xoá bài ${ui.post + 1}</button>` : "");
  $("#posts-hint").textContent = many()
    ? `Đang soạn Bài ${ui.post + 1}. Nội dung và ảnh bên dưới là của riêng bài này; mỗi nơi đã chọn sẽ nhận đủ ${form.posts.length} bài, đăng lần lượt.`
    : "Muốn đăng nhiều bài khác nhau (mỗi bài caption và ảnh riêng) vào cùng các nhóm thì bấm Thêm bài.";
  $("#files-h").textContent = many() ? `Ảnh hoặc video của Bài ${ui.post + 1}` : "Ảnh hoặc video";
}

function renderTexts() {
  const texts = cur().texts;
  $("#texts").innerHTML = texts.map((t, i) => `<div class="editor">
      <textarea id="t${i}" data-t="${i}" rows="${i ? 5 : 7}" aria-label="${texts.length > 1 ? `Bản viết ${i + 1}` : "Nội dung bài đăng"}" placeholder="Dán caption có sẵn vào đây…">${esc(t)}</textarea>
      <div class="count">${texts.length > 1 ? `<span>Bản viết ${i + 1}${i ? ` · <button type="button" class="link" data-trm="${i}">bỏ bản này</button>` : ""}</span>` : ""}<span id="n${i}"></span></div>
    </div>`).join("");
}

function renderGroups() {
  const list = glist(), q = $("#g-filter").value.trim().toLowerCase();
  const SHOW = { all: ["Tất cả", () => true], on: ["Đã chọn", g => g.on], off: ["Chưa chọn", g => !g.on], warn: ["Có cảnh báo", g => !!g.warn] };
  if (!list.some(SHOW[ui.gshow][1])) ui.gshow = "all";  // lọc đang chọn không còn nhóm nào thì về Tất cả
  $("#g-bar").hidden = !list.length;
  $("#g-sort").value = form.gsort || "new";
  $("#g-show").innerHTML = Object.entries(SHOW).map(([k, [label, test]]) => { const n = list.filter(test).length;
    return k === "warn" && !n ? "" : `<button type="button" data-gshow="${k}" aria-pressed="${ui.gshow === k}" ${n ? "" : "disabled"}>${label} <span>${n}</span></button>`; }).join("");
  $("#sec-groups").hidden = !form.dest.groups;
  $("#g-count").textContent = `${list.filter(g => g.on).length}/${list.length} nhóm`;
  $("#g-filter").hidden = list.length <= 8;
  $("#g-scan").innerHTML = ui.busy === "groups" ? SPIN + "Đang quét, khoảng một phút…" : "Quét nhóm";
  const all = items().filter(x => x.kind === "group"), done = new Set(all.filter(x => all.filter(y => y.url === x.url).every(postedAt)).map(x => x.url));
  // Chỉ đổi thứ tự hiển thị; data-gon / data-grm vẫn là vị trí trong danh sách lưu (thứ tự thêm vào)
  const order = list.map((g, i) => [g, i]);
  if ($("#g-sort").value === "new") order.reverse();
  else if ($("#g-sort").value === "az") order.sort((a, b) => gName(a[0]).localeCompare(gName(b[0]), "vi", { sensitivity: "base", numeric: true }));
  $("#g-list").innerHTML = order.map(([g, i]) => `<div class="grow" ${(q && !gName(g).toLowerCase().includes(q)) || !SHOW[ui.gshow][1](g) ? "hidden" : ""}>
      <label><input type="checkbox" data-gon="${i}" ${g.on ? "checked" : ""}><span>${esc(gName(g))}</span></label>
      ${g.on && done.has(g.url) ? '<span class="pill ok" title="Bài đang soạn đã đăng lên nhóm này. Bấm Đăng sẽ bỏ qua nhóm này.">Đã đăng bài này</span>' : ""}
      ${g.warn ? `<span class="pill warn gwarn" title="Ghi nhận ngày ${esc(g.warn.at)}, trong lượt đăng gần nhất có nhóm này. Lượt đăng mới sẽ xoá cảnh báo.">${esc(g.warn.text)}</span>` : ""}
      <a href="${esc(g.url)}" target="_blank" rel="noopener" title="Mở nhóm trong tab mới">${esc(g.url.replace("https://www.", ""))}</a>
      <button type="button" class="x" data-grm="${i}" aria-label="Bỏ nhóm ${esc(gName(g))} khỏi danh sách">✕</button></div>`).join("");
}

function renderFiles() {
  $("#thumbs").innerHTML = pfiles(cur()).map(f => `<figure title="${esc(f.name)}">${f.type.startsWith("video/")
      ? `<video src="${fileUrl(f)}" muted preload="metadata"></video>` : `<img src="${fileUrl(f)}" alt="${esc(f.name)}">`}
      <button type="button" class="x" data-frm="${f.id}" aria-label="Bỏ file ${esc(f.name)}">✕</button></figure>`).join("")
    + `<label class="addfile"><input type="file" id="files" accept="image/*,video/mp4,video/quicktime,video/webm" multiple><b>Thêm ảnh hoặc video</b><small>Kéo thả hoặc bấm để chọn file</small></label>`;
}

/* Xem trước đúng bản sẽ đăng: tab Facebook lật qua từng nhóm / trang cá nhân, tab Threads là bản Threads */
function renderPreview() {
  $$("[data-pv]").forEach(b => b.setAttribute("aria-selected", b.dataset.pv === ui.pvTab));
  const list = items().filter(x => (x.kind === "th") === (ui.pvTab === "th"));
  if (!list.length) {
    $("#pv").innerHTML = `<p class="empty">${ui.pvTab === "th" ? "Chưa chọn Threads ở mục Chọn nơi đăng." : "Chưa chọn nhóm hay trang cá nhân nào."}</p>`;
    return;
  }
  ui.pvI = Math.min(ui.pvI, list.length - 1);
  const x = list[ui.pvI], fs = x.files.map(id => ui.files.find(f => f.id === id)).filter(Boolean), f = fs[0], who = (ui.pvTab === "fb" && st.account?.fb.name) || "Tài khoản của bạn";
  const text = esc(x.text).replace(/(^|\s)(#[^\s#]+)/g, '$1<span class="tag">$2</span>');
  const varied = form.touch || form.posts.some(p => p.texts.some(t => /\{[^{}]*\|[^{}]*\}/.test(t)));
  $("#pv").innerHTML = `<div class="pvnav">${list.length > 1 ? `<button type="button" class="x" data-pvstep="-1" aria-label="Nơi trước">‹</button>` : ""}
      <b>${esc(iname(x))}</b>${list.length > 1 ? `<span class="muted">${ui.pvI + 1}/${list.length}</span><button type="button" class="x" data-pvstep="1" aria-label="Nơi sau">›</button>` : ""}</div>
    <div class="post">
      <div class="ph"><span class="avatar">${esc(initials(who))}</span><span><b>${esc(who)}</b><small>Vừa xong${x.kind === "group" ? ` · trong ${esc(x.name)}` : ""}</small></span></div>
      <div class="pt">${text || '<span class="muted">(không có chữ)</span>'}</div>
      ${f ? `<div class="pm">${f.type.startsWith("video/") ? `<video src="${fileUrl(f)}" muted preload="metadata"></video>` : `<img src="${fileUrl(f)}" alt="">`}${fs.length > 1 ? `<span>+${fs.length - 1}</span>` : ""}</div>` : ""}
      <div class="pf"><span>Thích</span><span>Bình luận</span><span>Chia sẻ</span></div>
    </div>
    <div class="pvfoot"><small class="muted">Đây là đúng bản sẽ đăng ở lượt này.</small>${varied ? '<button type="button" class="btn" data-act="reroll">Đổi cách biến tấu</button>' : ""}</div>`;
}

const mmss = s => s >= 3600 ? `${Math.floor(s / 3600)}:${String(Math.floor(s / 60) % 60).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}` : `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
const counts = j => { const n = s => j.items.filter(x => x.status === s).length;
  return `${n("da-dang")} đã đăng · ${n("cho-duyet")} chờ duyệt · ${n("loi")} lỗi${n("canh-bao") ? ` · ${n("canh-bao")} nhóm bị bỏ qua vì cảnh báo` : ""}${n("bo-qua") ? ` · ${n("bo-qua")} chưa đăng` : ""}`; };
/* Tên file ảnh chụp: số thứ tự lượt, nơi đăng không dấu, ngày. Ví dụ automkt-03-Noi-that-dep-Sai-Gon-lan-2-2026-10-11.jpg */
function shotName(key) {
  const i = st.job?.items.findIndex(x => x.shot === key) ?? -1, it = i >= 0 ? st.job.items[i] : null;
  const name = (it ? iname(it) : "soan-thu").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/đ/g, "d").replace(/Đ/g, "D").replace(/[^A-Za-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 60);
  return `automkt-${it ? String(i + 1).padStart(2, "0") + "-" : ""}${name || "anh-chup"}-${new Date().toISOString().slice(0, 10)}.jpg`;
}
/* Tải các ảnh chụp về máy; trả về số ảnh đã tải. Nhiều ảnh thì tải lần lượt, trình duyệt có thể hỏi cho phép tải nhiều file một lần. */
async function saveShots(keys) {
  let n = 0;
  for (const key of keys) {
    const s = await idb.get("shots", key);
    if (!s) continue;
    const a = Object.assign(document.createElement("a"), { href: s.url, download: shotName(key) });
    document.body.append(a); a.click(); a.remove();
    n++;
    if (keys.length > 1) await new Promise(r => setTimeout(r, 350));
  }
  return n;
}
const jobRows = (j, shots) => j.items.map(x => `<div class="jrow"><b>${esc(iname(x))}</b>${x.at ? `<span class="time">${esc(x.at)}</span>` : ""}
    ${shots && x.shot ? `<button type="button" class="link" data-shot="${esc(x.shot)}">ảnh chụp</button><button type="button" class="link" data-dl="${esc(x.shot)}" aria-label="Tải ảnh chụp của ${esc(iname(x))} về máy">tải về</button>` : ""}<span class="pill ${STATUS[x.status][1]}">${STATUS[x.status][0]}</span></div>
    ${x.error && x.error !== j.note ? `<small class="errline">${esc(x.error)}</small>` : ""}`).join("");
const jobTitle = j => j.status === "blocked" ? "Facebook chặn, đã dừng cả lượt" : j.status === "stopped" ? "Đã dừng giữa chừng" : "Lượt đăng gần nhất";

function renderJob() {
  const j = st.job, el = $("#job");
  el.hidden = !j;
  if (!j) return;
  const run = running(), wait = j.next_at ? Math.max(0, Math.round((j.next_at - Date.now()) / 1000)) : null;
  el.className = `callout ${j.status === "blocked" ? "bad" : j.status === "done" ? "ok" : ""} ${run ? "live" : ""}`;
  el.innerHTML = `<div class="head"><b>${run ? `Đang đăng: xong ${j.items.filter(x => !["cho", "dang-chay"].includes(x.status)).length}/${j.items.length} lượt` : jobTitle(j)}</b>
      ${run ? `<span class="muted">${wait !== null ? `lượt tiếp theo sau ${mmss(wait)}` : "đang thao tác trong cửa sổ làm việc…"}</span><button type="button" class="btn bad" id="stop">Dừng</button>`
        : `<span class="muted">${counts(j)}</span>${j.items.some(x => x.shot) ? `<button type="button" class="btn soft" data-dlall>Tải ${j.items.filter(x => x.shot).length} ảnh chụp</button>` : ""}`}</div>
    ${j.note ? `<p style="margin-bottom:8px">${esc(j.note)}</p>` : ""}${jobRows(j, true)}`;
}

function renderBar() {
  const p = places(), g = p.filter(x => x.kind === "group").length, np = form.posts.length, miss = missing(), busy = running() || !!ui.busy;
  const n = form.posts.reduce((s, post) => s + pfiles(post).length, 0);
  // Lượt nào bài đã lên nơi đó rồi thì bấm Đăng sẽ bỏ qua; đã đăng hết thì bấm Đăng là đăng lại tất cả
  const all = items(), fresh = all.filter(x => !postedAt(x)), again = all.length > 0 && !fresh.length;
  const todo = again ? all : fresh, skip = all.length - todo.length, nw = new Set(todo.map(x => x.where)).size;
  const R = rep(), multi = many() || R > 1;
  const rest = Math.round(todo.slice(1).reduce((s, x, i) => s + (x.round !== todo[i].round ? form.repLo + form.repHi
    : x.where === todo[i].where ? form.minLo + form.minHi : form.outLo + form.outHi), 0) / 2);  // tổng thời gian nghỉ, phút
  const dur = m => m >= 120 ? `${Math.round(m / 6) / 10} giờ` : `${m} phút`;
  const w = slot(todo.length), tight = w && todo.length > 1 && w.step < 60_000;
  const wtext = w && `khung ${form.winFrom}–${form.winTo}${w.tomorrow ? " ngày mai" : ""}${todo.length > 1 ? `, khoảng ${secs(w.step)} mỗi lượt` : ""}`;
  $("#gap-out").hidden = $("#gap-note").hidden = !!form.win;
  $("#win-row").hidden = !form.win;
  $("#win-info").hidden = !w;
  $("#win-info").className = tight ? "warntext" : "";
  $("#win-info").textContent = !w ? "" : `${w.later ? `Bắt đầu lúc ${hhmm(w.start)}${w.tomorrow ? " ngày mai" : ""}` : `Bắt đầu ngay, tới ${hhmm(w.end)}`}${todo.length > 1 ? `, mỗi lượt cách nhau khoảng ${secs(w.step)}` : ""}.`
    + (tight ? " Khoảng cách dưới 1 phút: đăng dồn dập dễ bị Facebook đánh dấu spam. Vẫn đăng được, nhưng nên nới khung giờ hoặc giảm số lượt." : "");
  const gaps = (many() ? `nghỉ ${form.minLo}–${form.minHi} phút giữa hai bài cùng nơi, ${form.outLo}–${form.outHi} phút khi sang nơi khác` : `nghỉ ${form.outLo}–${form.outHi} phút giữa hai nơi`)
    + (R > 1 ? `, ${repGap()} phút giữa hai lần lặp` : "");
  const gapsShown = w ? wtext : gaps;
  $("#bar").hidden = view() !== "soan";
  $("#opt-sub").textContent = (many() ? `Nghỉ ${form.minLo}–${form.minHi} phút giữa hai bài, ${form.outLo}–${form.outHi} phút giữa hai nơi` : `Nghỉ ${form.outLo}–${form.outHi} phút`)
    + (R > 1 ? ` · lặp ${R} lần, cách ${repGap()} phút` : "");
  if (form.win) $("#opt-sub").textContent = `Khung giờ ${form.winFrom}–${form.winTo}${R > 1 ? ` · lặp ${R} lần` : ""}`;
  $("#gap-in").hidden = !many() || !!form.win;
  $("#gap-rep").hidden = R < 2 || !!form.win;
  $("#sum").innerHTML = p.length ? `${multi ? `${todo.length} lượt đăng` : `${nw} nơi đăng`} <span>${[multi && !skip && [many() && `${np} bài`, `${p.length} nơi`, R > 1 && `${R} lần`].filter(Boolean).join(" × "),
    skip && `bỏ qua ${skip} ${multi ? "lượt" : "nơi"} đã đăng bài này`, again && "các nơi này đã đăng bài này rồi", n ? `${n} file` : "không kèm ảnh", !w && rest && `nghỉ khoảng ${dur(rest)}`, tight && "khoảng cách dưới 1 phút"].filter(Boolean).join(" · ")}</span>` : "Chưa chọn nơi đăng";
  $("#sum2").textContent = [g && `Nhóm Facebook (${new Set(todo.filter(x => x.kind === "group").map(x => x.where)).size})`, form.dest.feed && "Trang cá nhân Facebook", form.dest.th && "Threads", gapsShown].filter(Boolean).join(" · ");
  $("#form").disabled = busy;
  $("#try").disabled = $("#go").disabled = busy || !!miss;
  $("#try").innerHTML = ui.busy === "try" ? SPIN + "Đang soạn thử…" : "Soạn thử";
  $("#go").innerHTML = running() ? SPIN + "Đang đăng…" : again ? (multi ? `Đăng lại ${todo.length} lượt` : `Đăng lại lên ${nw} nơi`)
    : skip ? (multi ? `Đăng ${todo.length} lượt còn lại` : `Đăng lên ${nw} nơi còn lại`)
    : R > 1 ? `Đăng ${todo.length} lượt lên ${p.length} nơi` : many() ? `Đăng ${np} bài lên ${p.length} nơi` : `Đăng lên ${p.length} nơi`;
  $("#lock").hidden = !miss || busy;
  $("#lock-d").textContent = miss;
  $("#drop-th").hidden = busy || !(form.dest.th && st.account && !st.account.th.in);
  $("#err").hidden = !ui.err;
  $("#err").textContent = ui.err || "";
  const t = st.tried;
  $("#tried").hidden = !t;
  if (t) $("#tried").innerHTML = `<b>Soạn thử ở “${esc(t.name)}” chạy được</b> lúc ${esc(t.at)}; bài đã bỏ, chưa đăng gì.<br><small>${esc(t.note || "")}</small>
    ${t.shot ? ` <button type="button" class="link" data-shot="${esc(t.shot)}">Xem ảnh chụp khung soạn bài</button>` : '<br><small>Không có ảnh chụp vì chưa bật “Kèm ảnh chụp màn hình”.</small>'}`;
}

function renderViews() {
  const v = view(), a = st.account, list = glist(), j = st.job;
  [$("#title").textContent, $("#subtitle").textContent] = VIEWS[v];
  $$("[data-view]").forEach(el => el.hidden = el.dataset.view !== v);
  $$("[data-nav]").forEach(el => el.dataset.nav === v ? el.setAttribute("aria-current", "page") : el.removeAttribute("aria-current"));
  const tile = (label, value, sub) => `<div class="card tile"><small>${label}</small><b>${esc(value)}</b><small>${esc(sub)}</small></div>`;
  $("#v-home").innerHTML = `<div class="tiles">
      ${tile("Nick Facebook", a?.fb.in ? a.fb.name || "Đã đăng nhập" : "Chưa có", a ? `quét lúc ${a.at}` : "chưa quét tài khoản")}
      ${tile("Nhóm đã lưu", list.length, `${list.filter(g => g.on).length} nhóm đang tick`)}
      ${tile("Bài đang soạn", form.posts.length, `${ui.files.length} file đính kèm`)}
      ${tile("Số lượt đã chạy", st.history.length, j ? (running() ? "đang chạy một lượt" : jobTitle(j).toLowerCase()) : "chưa chạy lượt nào")}</div>
    ${j ? `<section class="card"><div class="head"><h2>${running() ? "Lượt đang chạy" : jobTitle(j)}</h2><span class="muted">${counts(j)}</span></div>${jobRows(j, true)}</section>` : ""}
    <div><a class="btn primary" href="#soan">Soạn bài mới</a></div>`;
  $("#v-history").innerHTML = st.history.length
    ? st.history.map(h => `<section class="card"><div class="head"><h2>${new Date(h.started).toLocaleString("vi-VN", { dateStyle: "short", timeStyle: "short" })}
        · ${h.status === "done" ? "chạy xong" : h.status === "blocked" ? "Facebook chặn" : "dừng giữa chừng"}</h2><span class="muted">${counts(h)}</span></div>
        ${h.note ? `<p class="errline">${esc(h.note)}</p>` : ""}${jobRows(h, false)}</section>`).join("")
    : '<section class="card empty">Chưa có lượt đăng nào. Lịch sử giữ 30 lượt gần nhất, chỉ lưu trên máy này.</section>';
  $("#perm-more").innerHTML = ui.canMore ? '<span class="pill ok">Đã cấp</span>' : '<button type="button" class="btn" data-act="more-perm">Cấp quyền</button>';
  $("#perm-shots").innerHTML = `<span class="pill ${ui.canShot ? "ok" : ""}">${ui.canShot ? "Đang bật" : "Đang tắt"}</span>`;
}

function renderStatic() {
  $("#th-tab-ic").innerHTML = ICON.th;
  $("#touch").checked = form.touch;
  $("#g-addpick").checked = form.addPick !== false;
  $("#gmin").value = form.outLo;
  $("#gmax").value = form.outHi;
  $("#pmin").value = form.minLo;
  $("#pmax").value = form.minHi;
  $("#rep").value = rep();
  $("#rep").disabled = !EDITION.repeat;  // bản công khai khoá đăng lặp lại
  $("#rep-lock").hidden = EDITION.repeat;
  $("#g-max").textContent = MAX_GROUPS;
  if (EDITION.name) $("#edition").textContent = EDITION.name;
  $("#edition").hidden = !EDITION.name;
  $("#rmin").value = form.repLo;
  $("#rmax").value = form.repHi;
  $("#win").checked = !!form.win;
  $("#wfrom").value = form.winFrom;
  $("#wto").value = form.winTo;
  $("#shots").checked = ui.canShot;
}

function renderPost() {  // đổi bài đang soạn: vẽ lại dải chọn bài và các ô của bài đó
  ui.post = Math.min(ui.post, form.posts.length - 1);
  renderTexts(); renderFiles();
  $("#th-text").value = cur().thText;
  renderLight();
}

function renderLight() {  // những chỗ đổi theo từng phím gõ, không đụng ô đang nhập
  renderPosts(); renderTabs(); renderPreview(); renderBar();
}

function render() {
  renderViews(); renderDests(); renderAcct(); renderGroups(); renderJob(); renderLight();
}

/* ---------- sự kiện ---------- */
async function busy(name, fn) {
  ui.busy = name; ui.err = null;
  render();
  try { await fn(); } finally { ui.busy = null; render(); }
}

const scan = () => busy("scan", async () => {
  const r = await send("scan");
  if (!r.ok) ui.err = r.error;
});

const ACTIONS = {
  scan,
  groups: () => busy("groups", async () => {
    const r = await send("groups");
    if (r.ok) toast(`Đọc được ${r.data.found} nhóm, ${r.data.fresh} nhóm mới`);
    else ui.err = r.error;
  }),
  "more-perm": async () => {
    ui.canMore = await chrome.permissions.request(MORE_SITES);
    if (ui.canMore) scan(); else renderViews();
  },
  full: async () => { await chrome.tabs.create({ url: chrome.runtime.getURL("app.html") }); window.close(); },
  reroll: () => { form.seed = Math.floor(Math.random() * 1e9); saveForm(); renderPreview(); },
  "post-add": () => {
    form.posts.push({ id: Date.now(), texts: [""], thText: "" });
    ui.post = form.posts.length - 1; ui.tab = "main";
    saveForm(); renderPost(); $("#t0").focus();
  },
  "post-del": async () => {
    const post = cur(), fs = pfiles(post);
    if ((post.texts.some(t => t.trim()) || fs.length) && !confirm(`Xoá Bài ${ui.post + 1} cùng nội dung và ${fs.length} file của bài đó?`)) return;
    for (const f of fs) { await idb.del("files", f.id); URL.revokeObjectURL(ui.urls.get(f.id)); ui.urls.delete(f.id); }
    form.posts.splice(ui.post, 1);
    ui.post = Math.max(0, ui.post - 1);
    saveForm(); await loadFiles();
  },
  "drop-th": () => { form.dest.th = false; saveForm(); render(); },
  wipe: async () => {
    if (running()) return toast("Đang có lượt đăng chạy, bấm Dừng trước");
    if (!confirm("Xoá toàn bộ dữ liệu của extension trên máy này?\n\nDanh sách nhóm, nội dung đang soạn, file đính kèm, lịch sử và ảnh chụp sẽ mất. Không hoàn tác được.")) return;
    await chrome.storage.local.clear();
    await idb.clear("files");
    await idb.clear("shots");
    location.hash = "#soan";
    location.reload();
  },
};

document.addEventListener("click", async e => {
  const t = e.target.closest("[data-act],[data-shot],[data-dl],[data-dlall],[data-tab],[data-pv],[data-pvstep],[data-post]");
  if (!t) return;
  const d = t.dataset;
  if (d.dl !== undefined || d.dlall !== undefined) {
    const n = await saveShots(d.dl !== undefined ? [d.dl] : st.job.items.map(x => x.shot).filter(Boolean));
    return toast(n ? `Đã tải ${n} ảnh chụp về thư mục Tải xuống` : "Không còn ảnh chụp này");
  }
  if (d.act) return ACTIONS[d.act]();
  if (d.post) { ui.post = +d.post; renderPost(); return $(`[data-post="${ui.post}"]`).focus(); }
  if (d.tab) { ui.tab = d.tab; return renderTabs(); }
  if (d.pv) { ui.pvTab = d.pv; ui.pvI = 0; return renderPreview(); }
  if (d.pvstep) {
    const n = items().filter(x => (x.kind === "th") === (ui.pvTab === "th")).length;
    ui.pvI = (ui.pvI + +d.pvstep + n) % n;
    return renderPreview();
  }
  const s = await idb.get("shots", d.shot);  // ảnh chụp nằm trong IndexedDB dưới dạng data URL
  if (!s) return toast("Không còn ảnh chụp này");
  $("#shot img").src = s.url;
  Object.assign($("#shot-dl"), { href: s.url, download: shotName(d.shot) });
  $("#shot").showModal();
});

$("#pv-toggle").onclick = e => {
  const open = body.classList.toggle("show-pv");
  e.currentTarget.setAttribute("aria-expanded", open);
  if (open) $("#pv-card").scrollIntoView({ block: "nearest", behavior: "smooth" });
};
$("#g-filter").oninput = renderGroups;
$("#g-sort").onchange = e => { form.gsort = e.target.value; saveForm(); renderGroups(); };
$("#g-show").onclick = e => {
  const k = e.target.closest("[data-gshow]")?.dataset.gshow;
  if (k) { ui.gshow = k; renderGroups(); }
};
$("#g-addtoggle").onclick = e => {
  const open = $("#g-addbox").hidden;
  $("#g-addbox").hidden = !open;
  e.currentTarget.setAttribute("aria-expanded", open);
  if (open) $("#g-add").focus();
};

$("#g-addpick").onchange = e => { form.addPick = e.target.checked; saveForm(); };
$("#g-addgo").onclick = async () => {
  const list = glist(), bad = [], pick = form.addPick !== false;
  let added = 0, picked = 0, full = 0, warned = 0;
  for (const line of $("#g-add").value.split("\n").map(x => x.trim()).filter(Boolean)) {
    const url = normalize(line);
    if (!url) { bad.push(line); continue; }
    let g = list.find(g => g.url === url);
    if (!g) { list.push(g = { url, name: "", on: false }); added++; }
    if (!pick || g.on) continue;
    if (list.filter(g => g.on).length >= MAX_GROUPS) full++;
    else { g.on = true; picked++; }
  }
  await saveGroups(list);
  $("#g-add").value = "";
  ui.err = bad.length ? `Không phải link nhóm Facebook, đã bỏ qua: ${bad.join(" · ")}` : null;
  if (added || picked || full || warned) toast([added ? `Đã thêm ${added} nhóm` : "Nhóm đã có sẵn", picked && `đã chọn ${picked}`,
    full && `${full} nhóm chưa chọn vì quá ${MAX_GROUPS} nhóm một lượt`, warned && `${warned} nhóm có cảnh báo, chưa chọn`].filter(Boolean).join(" · "));
  render();
};

$("#g-list").onchange = async e => {
  const i = e.target.dataset.gon, list = glist();
  if (i === undefined) return;
  if (e.target.checked && list.filter(g => g.on).length >= MAX_GROUPS) {
    e.target.checked = false;
    return toast(`Mỗi lượt tối đa ${MAX_GROUPS} nhóm`);
  }
  const g = list[+i];
  g.on = e.target.checked;
  await saveGroups(list);
  render();
};

$("#g-list").onclick = async e => {
  const i = e.target.dataset.grm;
  if (i === undefined) return;
  const list = glist();
  list.splice(+i, 1);
  await saveGroups(list);
  render();
};

/* Mọi ô nhập trong form: đọc vào `form`, lưu lại, vẽ lại phần phụ thuộc */
$("#form").addEventListener("input", e => {
  const t = e.target;
  if (t.dataset.t !== undefined) cur().texts[+t.dataset.t] = t.value;
  else if (t.dataset.dest) form.dest[t.dataset.dest] = t.checked;
  else if (t.id === "th-text") cur().thText = t.value;
  else if (t.id === "touch") form.touch = t.checked;
  else if (t.id === "win") form.win = t.checked;
  else if (t.id === "wfrom" || t.id === "wto") { if (/^\d\d:\d\d$/.test(t.value)) form[t.id === "wfrom" ? "winFrom" : "winTo"] = t.value; }
  else if (["gmin", "gmax", "pmin", "pmax", "rep", "rmin", "rmax"].includes(t.id)) {
    const num = (id, lo, hi) => Math.min(hi, Math.max(lo, Math.round(+$(id).value) || lo));
    form.outLo = num("#gmin", 1, 120); form.outHi = num("#gmax", form.outLo, 120);  // phút, tối thiểu 1
    form.minLo = num("#pmin", 1, 120); form.minHi = num("#pmax", form.minLo, 120);
    form.rep = num("#rep", 1, MAX_REP);
    form.repLo = num("#rmin", 1, 720); form.repHi = num("#rmax", form.repLo, 720);
  } else return;
  ui.err = null;
  if (st.tried) { st.tried = null; chrome.storage.local.set({ tried: null }); }
  saveForm();
  if (t.dataset.dest) {
    if (t.dataset.dest === "th") ui.pvTab = t.checked ? "th" : "fb";
    renderDests(); renderAcct(); renderGroups();
    $(`[data-dest="${t.dataset.dest}"]`).focus();
  }
  renderLight();
});
$("#gmin").onchange = $("#gmax").onchange = $("#pmin").onchange = $("#pmax").onchange = $("#rep").onchange = $("#rmin").onchange = $("#rmax").onchange = renderStatic;

$("#t-more").onclick = () => { cur().texts.push(""); saveForm(); renderTexts(); renderLight(); $(`#t${cur().texts.length - 1}`).focus(); };
$("#texts").onclick = e => {
  const i = e.target.dataset.trm;
  if (i === undefined) return;
  cur().texts.splice(+i, 1);
  saveForm(); renderTexts(); renderLight();
};

/* Chụp màn hình cần quyền "mọi trang web", chỉ xin khi người dùng bật */
$("#shots").onchange = async e => {
  ui.canShot = e.target.checked ? await chrome.permissions.request(ALL_URLS) : !await chrome.permissions.remove(ALL_URLS);
  e.target.checked = ui.canShot;
  ui.canMore = await chrome.permissions.contains(MORE_SITES);
  renderViews();
};

/* ---------- file ---------- */
async function loadFiles() {
  ui.files = (await idb.all("files")).sort((a, b) => a.id - b.id);
  renderPost(); renderViews();
}
async function addFiles(list) {
  const ok = [...list].filter(f => /^(image|video)\//.test(f.type));
  if (ok.length < list.length) toast("Chỉ nhận ảnh hoặc video");
  let id = Date.now();
  for (const f of ok) await idb.put("files", { id: id++, post: cur().id, name: f.name, type: f.type, size: f.size, blob: f });
  await loadFiles();
}
$("#thumbs").onchange = e => { if (e.target.id === "files") addFiles(e.target.files); };
$("#thumbs").onclick = async e => {
  const id = e.target.dataset.frm;
  if (id === undefined) return;
  await idb.del("files", +id);
  URL.revokeObjectURL(ui.urls.get(+id));
  ui.urls.delete(+id);
  await loadFiles();
};
body.ondragover = e => { if (view() === "soan" && e.dataTransfer?.types.includes("Files")) { e.preventDefault(); body.classList.add("drag"); } };
body.ondragleave = e => { if (!e.relatedTarget) body.classList.remove("drag"); };
body.ondrop = e => {
  body.classList.remove("drag");
  if (view() !== "soan" || !e.dataTransfer?.files.length) return;
  e.preventDefault();
  if (!running() && !ui.busy) addFiles(e.dataTransfer.files);
};

/* ---------- soạn thử, đăng, dừng ---------- */
const payload = () => ({ items: items(), files: [], gap: [form.outLo * 60, form.outHi * 60], gapIn: [form.minLo * 60, form.minHi * 60], gapRep: [form.repLo * 60, form.repHi * 60] });  // service worker nhận giây  // file đi theo từng lượt (item.files)

$("#try").onclick = () => busy("try", async () => {
  const p = payload();
  const r = await send("try", { item: p.items[0], files: p.items[0].files });
  if (!r.ok) ui.err = r.error;
});

$("#go").onclick = async () => {
  const p = payload();
  // Bài này đã lên nơi nào rồi thì bỏ qua nơi đó, chỉ chạy các lượt còn lại
  const dup = p.items.filter(postedAt);
  // mỗi nơi một dòng: "• Tên nhóm × 10 lượt"
  const lines = (list, day) => [...list.reduce((m, x) => m.set(x.where, { x, n: (m.get(x.where)?.n || 0) + 1 }), new Map()).values()]
    .map(({ x, n }) => `• ${x.name}${n > 1 ? ` × ${n} lượt` : ""}${day ? ` (${new Date(postedAt(x)).toLocaleDateString("vi-VN")})` : ""}`).join("\n");
  if (dup.length === p.items.length) {
    if (!confirm(`Bài này đã đăng lên tất cả các nơi đang chọn rồi:\n\n${lines(dup, true)}\n\nĐăng lại lần nữa lên các nơi này? Đăng trùng dễ bị Facebook đánh dấu spam.`)) return;
  } else {
    if (dup.length) p.items = p.items.filter(x => !postedAt(x));
    const who = st.account.fb.name || "đang đăng nhập";
    if (!confirm(`Đăng thật ${p.items.length} lượt bằng nick ${who}?\n\n${lines(p.items)}${rep() > 1 ? `\n\nMỗi bài lặp ${rep()} lần${form.win ? "" : `, hai lần cách nhau ${repGap()} phút`}. Giữ trình duyệt mở tới khi xong.` : ""}${dup.length ? `\n\nBỏ qua ${dup.length} lượt vì bài này đã đăng ở đó rồi:\n${lines(dup, true)}` : ""}`)) return;
  }
  const w = slot(p.items.length);
  if (w) {
    p.slot = { start: w.start, step: w.step };
    const tight = p.items.length > 1 && w.step < 60_000;
    if (!confirm(`Khung giờ ${form.winFrom}–${form.winTo}: ${w.later ? `bắt đầu lúc ${hhmm(w.start)}${w.tomorrow ? " ngày mai" : ""}` : `bắt đầu ngay, tới ${hhmm(w.end)}`}${p.items.length > 1 ? `, mỗi lượt cách nhau khoảng ${secs(w.step)}` : ""}. Giữ trình duyệt mở tới khi xong.${tight ? "\n\nCẢNH BÁO: khoảng cách giữa hai lượt dưới 1 phút, đăng dồn dập dễ bị Facebook đánh dấu spam." : ""}\n\nTiếp tục?`)) return;
  }
  ui.err = null;
  const r = await send("run", p);
  if (!r.ok) ui.err = r.error;
  render();
  if (r.ok) window.scrollTo({ top: 0, behavior: "smooth" });
};

$("#job").onclick = async e => {
  if (e.target.id !== "stop") return;
  e.target.disabled = true;
  await send("stop");
  if (running()) toast("Sẽ dừng sau nơi đang đăng");
};

/* ---------- đồng bộ với service worker ---------- */
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  const was = running();
  for (const k of ["account", "groups", "job", "tried", "history", "posted"])
    if (changes[k]) st[k] = changes[k].newValue ?? (k === "groups" || k === "posted" ? {} : k === "history" ? [] : null);
  if (changes.form?.newValue && !document.hasFocus()) {
    form = { ...form, ...changes.form.newValue };
    renderStatic(); renderPost();
  }
  if (was && !running())
    toast(st.job?.items.some(x => x.status === "canh-bao" || x.status === "cho-duyet") ? "Xong lượt đăng, có nhóm giữ bài chờ duyệt hoặc gỡ bài. Xem cảnh báo ở danh sách nhóm" : st.job?.status === "done" ? "Đã chạy xong lượt đăng" : st.job?.status === "blocked" ? "Facebook chặn, đã dừng lượt đăng" : "Đã dừng lượt đăng");
  if (changes.groups && document.activeElement?.closest("#g-list")) { renderJob(); renderLight(); } else render();
});
addEventListener("visibilitychange", () => { if (document.hidden) { clearTimeout(saveTimer); chrome.storage.local.set({ form }); } });
setInterval(() => { if (running() && st.job.next_at && !document.hidden) renderJob(); }, 1000);  // đồng hồ đếm ngược
addEventListener("hashchange", () => { render(); window.scrollTo(0, 0); });

(async () => {
  const saved = await chrome.storage.local.get(["account", "groups", "job", "tried", "history", "posted", "form"]);
  st = { account: saved.account || null, groups: saved.groups || {}, job: saved.job || null, tried: saved.tried || null, history: saved.history || [], posted: saved.posted || {} };
  if (saved.form) form = { ...form, ...saved.form, dest: { ...form.dest, ...saved.form.dest } };
  if (form.texts) {  // bản lưu kiểu cũ: một bài duy nhất nằm thẳng trong form
    if (!saved.form.posts?.length) form.posts = [{ id: 0, texts: form.texts.length ? form.texts : [""], thText: form.thText || "" }];
    delete form.texts; delete form.thText;
  }
  if (!form.posts?.length) form.posts = [{ id: 0, texts: [""], thText: "" }];
  ui.canShot = await chrome.permissions.contains(ALL_URLS);
  ui.canMore = await chrome.permissions.contains(MORE_SITES);
  if (form.dest.th && !form.dest.groups && !form.dest.feed) ui.pvTab = "th";
  if (POPUP) {  // cửa sổ nhỏ: gập bớt hai mục dài
    $("#sec-groups").open = $("#opts").open = false;
  }
  renderStatic(); renderPost(); render();
  await loadFiles();
})();
