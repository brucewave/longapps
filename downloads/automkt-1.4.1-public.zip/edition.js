/* Giới hạn theo phiên bản: bản công khai. */
export const EDITION = { name: "Bản công khai", maxGroups: 5, repeat: false };
