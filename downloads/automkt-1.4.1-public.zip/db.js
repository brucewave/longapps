/* IndexedDB dùng chung giữa trang giao diện và service worker: file đính kèm và ảnh chụp kết quả. */

const open = () => new Promise((resolve, reject) => {
  const req = indexedDB.open("automkt", 1);
  req.onupgradeneeded = () => {
    req.result.createObjectStore("files", { keyPath: "id" });  // {id, name, type, size, blob}
    req.result.createObjectStore("shots", { keyPath: "id" });  // {id, url}
  };
  req.onsuccess = () => resolve(req.result);
  req.onerror = () => reject(req.error);
});

async function tx(store, mode, fn) {
  const db = await open();
  return new Promise((resolve, reject) => {
    const t = db.transaction(store, mode);
    const req = fn(t.objectStore(store));
    t.oncomplete = () => { db.close(); resolve(req.result); };
    t.onerror = t.onabort = () => { db.close(); reject(t.error); };
  });
}

export const idb = {
  get: (store, id) => tx(store, "readonly", o => o.get(id)),
  all: store => tx(store, "readonly", o => o.getAll()),
  put: (store, value) => tx(store, "readwrite", o => o.put(value)),
  del: (store, id) => tx(store, "readwrite", o => o.delete(id)),
  clear: store => tx(store, "readwrite", o => o.clear()),
};
