/* Biến tấu caption và link nhóm. Chuyển từ automkt/groups.py và automkt/fb_group.py. */

// Biểu tượng cùng nghĩa, đổi qua lại để các bản không giống nhau từng ký tự
const SWAPS = [["✅", "✔️", "☑️"], ["🔹", "🔸", "▪️"], ["👉", "➡️", "▶️"], ["📞", "☎️"], ["🏠", "🏡"], ["📍", "📌"], ["🔥", "⚡"]];
const SPIN_RE = /\{([^{}]*\|[^{}]*)\}/;
const GROUP_RE = /(?:facebook|fb)\.com\/groups\/([^/?#\s]+)/i;

/** Đưa link nhóm về dạng https://www.facebook.com/groups/<id>/; không phải link nhóm thì trả null. */
export function normalize(link) {
  const m = GROUP_RE.exec(link.trim());
  return m ? `https://www.facebook.com/groups/${m[1]}/` : null;
}

/* Bộ sinh số ngẫu nhiên có seed (mulberry32): cùng seed cho cùng dãy số */
function rng(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const pick = (rand, arr) => arr[Math.floor(rand() * arr.length)];

/** {cách viết 1|cách viết 2}: mỗi nơi chọn ngẫu nhiên một cách. */
function spin(text, rand) {
  let m;
  while ((m = SPIN_RE.exec(text))) text = text.slice(0, m.index) + pick(rand, m[1].split("|")) + text.slice(m.index + m[0].length);
  return text;
}

/** Đổi nhẹ mà không đổi nghĩa: biểu tượng cùng loại và thứ tự hashtag ở dòng cuối. */
function touch(text, rand) {
  for (const group of SWAPS) {
    const chosen = pick(rand, group);
    for (const sym of [...group].sort((a, b) => b.length - a.length)) text = text.split(sym).join("\0");
    text = text.split("\0").join(chosen);
  }
  const lines = text.trimEnd().split("\n");
  const tags = lines[lines.length - 1].split(/\s+/).filter(Boolean);
  if (tags.length > 1 && tags.every(t => t.startsWith("#"))) {
    for (let i = tags.length - 1; i > 0; i--) {
      const j = Math.floor(rand() * (i + 1));
      [tags[i], tags[j]] = [tags[j], tags[i]];
    }
    lines[lines.length - 1] = tags.join(" ");
  }
  return lines.join("\n");
}

/** Bản caption cho từng nơi: xoay vòng các bản viết, rồi biến tấu. Cùng seed cho cùng kết quả,
 *  nên bản xem trước đúng là bản sẽ đăng. */
export function variants(texts, n, doTouch, seed) {
  texts = texts.map(t => t.replace(/\r\n/g, "\n").trim()).filter(Boolean);
  if (!texts.length) return Array(n).fill("");
  const rand = rng(seed);
  const out = [];
  for (let i = 0; i < n; i++) {
    const t = spin(texts[i % texts.length], rand);
    out.push(doTouch ? touch(t, rand) : t);
  }
  return out;
}
