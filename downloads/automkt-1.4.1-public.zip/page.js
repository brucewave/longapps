/* Chạy trong trang facebook.com / threads.com (service worker nạp vào rồi gọi từng hàm qua window.__amkt).
   Chuyển từ automkt/fb_group.py, fb_post.py và th_post.py. kind: "group" | "feed" | "th". */
(() => {
  if (window.__amkt) return;

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const all = (sel, root = document) => [...root.querySelectorAll(sel)];
  const vis = el => !!el && el.getClientRects().length > 0;
  const text = el => (el.innerText || el.textContent || "").trim();
  const letters = s => s.replace(/[^\p{L}\p{N}]/gu, "");

  const PUBLISH = '[role="button"][aria-label="Đăng"], [role="button"][aria-label="Post"]';
  const TRIGGERS = {
    group: ["bạn viết gì đi", "write something"],
    feed: ["bạn đang nghĩ gì", "what's on your mind"],
  };
  // Facebook đang hạn chế tài khoản: phải dừng cả lượt đăng, không thử nơi tiếp theo
  const BLOCKED = ["tạm thời bị chặn", "tạm thời bị hạn chế", "Chúng tôi giới hạn", "Bạn hiện không thể đăng",
                   "temporarily blocked", "We limit how often"];

  function trigger(kind) {
    if (kind === "th")
      return all('[role="button"][aria-label^="Trường văn bản trống"], [role="button"][aria-label^="Empty text field"]').find(vis);
    return all('[role="main"] [role="button"]').find(b => vis(b) && TRIGGERS[kind].some(t => text(b).toLowerCase().includes(t)));
  }

  function dialog(kind) {
    return all('[role="dialog"]').find(d => vis(d) && d.querySelector('[role="textbox"]') && (kind === "th" || d.querySelector(PUBLISH)));
  }

  /* Nút có đúng chữ `re` (không lẫn với nút "Đăng vào 19:30...") */
  const button = (root, re) => all('[role="button"]', root).filter(b => vis(b) && re.test(text(b)));

  function publishBtn(kind) {
    const d = dialog(kind);
    if (!d) return null;
    return kind === "th" ? button(d, /^(Đăng|Post)$/).pop() : d.querySelector(PUBLISH);
  }

  /* Bấm giả lập: đủ chuỗi sự kiện chuột như một lần bấm thật */
  function press(el) {
    el.scrollIntoView({ block: "center" });
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, composed: true, view: window, button: 0,
                clientX: r.x + r.width / 2, clientY: r.y + r.height / 2 };
    const p = { ...o, pointerId: 1, pointerType: "mouse", isPrimary: true };
    el.dispatchEvent(new PointerEvent("pointerdown", p));
    el.dispatchEvent(new MouseEvent("mousedown", o));
    el.dispatchEvent(new PointerEvent("pointerup", p));
    el.dispatchEvent(new MouseEvent("mouseup", o));
    el.click();
  }

  /* Điền chữ vào ô soạn Lexical: dán giả lập trước, không vào thì gõ từng dòng bằng insertText.
     Trả về cách đã dùng và số chữ đối chiếu được. */
  async function type(kind, value) {
    const box = dialog(kind)?.querySelector('[role="textbox"]');
    if (!box) throw new Error("Không thấy ô nhập chữ trong khung soạn bài.");
    value = value.replace(/\r\n/g, "\n");
    const want = letters(value);
    const has = () => want ? letters(text(box)).includes(want.slice(0, 40)) : text(box).length > 0;
    const result = how => ({ how, got: letters(text(box)).length, want: want.length });

    press(box);
    box.focus();
    await sleep(500);  // Lexical đồng bộ vùng chọn qua selectionchange, cần một nhịp
    const dt = new DataTransfer();
    dt.setData("text/plain", value);
    box.dispatchEvent(new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true }));
    await sleep(800);
    if (has()) return result("dán");

    box.focus();
    const lines = value.split("\n");
    for (let i = 0; i < lines.length; i++) {
      if (lines[i]) document.execCommand("insertText", false, lines[i]);
      if (i < lines.length - 1) document.execCommand("insertLineBreak");
      await sleep(40);
    }
    await sleep(600);
    if (has()) return result("gõ");
    throw new Error("Ô soạn bài không nhận chữ (đã thử cả dán và gõ).");
  }

  /* File đi từ service worker sang theo từng khúc base64, ghép lại thành File ở đây */
  const parts = {};
  let files = [];
  function filesReset() { files = []; for (const k in parts) delete parts[k]; }
  function filesPush(id, b64) {
    const s = atob(b64), u = new Uint8Array(s.length);
    for (let i = 0; i < s.length; i++) u[i] = s.charCodeAt(i);
    (parts[id] ||= []).push(u);
  }
  function filesDone(id, name, mime) {
    files.push(new File(parts[id] || [], name, { type: mime }));
    delete parts[id];
  }

  async function attach(kind) {
    let input = dialog(kind)?.querySelector('input[type="file"]');
    if (!input && kind !== "th") {  // ô chọn file chỉ hiện sau khi bấm nút Ảnh/video
      const b = dialog(kind)?.querySelector('[aria-label="Ảnh/video"], [aria-label="Photo/video"]');
      if (b) { press(b); await sleep(1500); }
      input = dialog(kind)?.querySelector('input[type="file"]');
    }
    if (!input) throw new Error("Không thấy ô chọn file trong khung soạn bài.");
    const dt = new DataTransfer();
    for (const f of files) dt.items.add(f);
    input.files = dt.files;
    input.dispatchEvent(new Event("change", { bubbles: true }));
    return input.files.length;
  }

  /* Nhãn AI trong khung soạn: đang bật thì tắt đi, không bao giờ bật. Khung soạn trang cá nhân / nhóm có nút
     "Nhãn AI đang tắt" / "Nhãn AI đang bật"; khung soạn của fanpage dùng công tắc trong dòng "Thêm nhãn AI".
     Trả về "khong-thay" | "dang-tat" | "da-tat" | "con-bat". */
  async function aiLabelOff(kind) {
    const label = b => b.getAttribute("aria-label") || text(b);
    const btn = re => all('[role="button"]', dialog(kind) || document.createElement("i")).find(b => vis(b) && re.test(label(b)));
    const ON = /nhãn AI đang bật|AI label (is )?on/i, OFF = /nhãn AI đang tắt|AI label (is )?off/i;
    const AI = /nhãn AI|AI label|thông tin (về|do) AI|AI info/i;
    const on = s => s.getAttribute("aria-checked") === "true" || s.checked === true;
    const toggle = () => {
      const d = dialog(kind);
      return d && all('[role="switch"], input[type="checkbox"]', d).find(s => {
        for (let p = s, i = 0; p && p !== d && i < 6; p = p.parentElement, i++) {
          const t = p.getAttribute?.("aria-label") || text(p);
          if (t.length < 200 && AI.test(t)) return true;
        }
        return false;
      });
    };
    const isOn = () => !!btn(ON) || (!!toggle() && on(toggle()));
    if (!btn(ON) && !btn(OFF) && !toggle()) return "khong-thay";
    if (!isOn()) return "dang-tat";
    for (let i = 0; i < 2 && isOn(); i++) {
      const sw = toggle();
      press(btn(ON) || sw.closest('[role="button"]') || sw);
      await sleep(1200);
    }
    return isOn() ? "con-bat" : "da-tat";
  }

  /* Trang cá nhân: bài phải ở chế độ Công khai. Trả về "khong-thay" | "san" | "da-doi" | "khong-doi". */
  async function audiencePublic(kind) {
    const PUB = /Công khai|Public/i;
    const btn = () => all('[role="button"]', dialog(kind) || document.createElement("i"))
      .find(b => /^(Chỉnh sửa quyền riêng tư|Edit privacy)/i.test(b.getAttribute("aria-label") || ""));
    let b = btn();
    if (!b) return "khong-thay";
    if (PUB.test(b.getAttribute("aria-label"))) return "san";
    press(b);
    let row;
    for (let i = 0; i < 10 && !row; i++) {
      await sleep(600);
      row = all('[role="radiogroup"] label').find(l => vis(l) && /^(Công khai|Public)(\n|$)/.test(text(l)));
    }
    if (row) {
      press(row.querySelector('input[type="radio"]') || row);
      await sleep(900);
      const done = button(document, /^(Xong|Done)$/).pop();
      if (done) { press(done); await sleep(1500); }
    }
    if (!btn()) {  // còn kẹt ở màn chọn đối tượng: quay lại khung soạn
      const back = all('[role="dialog"] [role="button"][aria-label="Quay lại"], [role="dialog"] [role="button"][aria-label="Back"]').find(vis);
      if (back) { press(back); await sleep(1200); }
    }
    b = btn();
    return b && PUB.test(b.getAttribute("aria-label")) ? "da-doi" : "khong-doi";
  }

  /* Bỏ bài đang soạn mà không đăng */
  async function cancel(kind) {
    const d = dialog(kind);
    if (!d) return;
    if (kind === "th") {
      const b = button(d, /^(Hủy|Cancel)$/)[0];
      if (b) { press(b); await sleep(1300); }
      const drop = button(document, /^(Không lưu|Don.t save|Discard)$/).pop();  // hỏi "Lưu làm bản nháp?"
      if (drop) { press(drop); await sleep(1200); }
      return;
    }
    const box = d.querySelector('[role="textbox"]');
    if (box) {
      box.focus();
      document.execCommand("selectAll");
      await sleep(300);
      document.execCommand("delete");
      await sleep(400);
    }
    const close = d.querySelector('[aria-label="Đóng"], [aria-label="Close"]');
    if (close) { press(close); await sleep(1300); }
    const leave = button(document, /^(Rời khỏi|Bỏ|Bỏ bài viết|Leave|Discard)$/).pop();
    if (leave) { press(leave); await sleep(1000); }
  }

  /* Đóng các hộp thoại xin quyền thông báo hay che khung soạn bài */
  function dismiss() {
    for (const sel of ['[role="alertdialog"] [role="button"]',
                       '[role="dialog"][aria-label="Hướng dẫn bật thông báo trình duyệt"] [aria-label="Đóng"]'])
      for (const b of all(sel))
        if (vis(b) && (sel.includes("aria-label") || /^(Đóng|Close)$/.test(text(b)))) press(b);
  }

  /* Số bài của mình đang chờ quản trị viên duyệt, đọc từ dải thông báo đầu trang nhóm (0 nếu không có) */
  function pending() {
    const el = all('[role="main"] span, [role="main"] div')
      .find(e => e.children.length === 0 && /chờ quản trị viên phê duyệt|pending approval/i.test(e.textContent));
    if (!el) return 0;
    const m = (el.parentElement.parentElement.innerText || "").match(/(\d+)\s*bài viết/);
    return m ? +m[1] : 1;
  }

  /* Trang "Nội dung của bạn" trong nhóm (/my_declined_content, /my_removed_content): số bài của mình đang nằm ở mục đó.
     -1: trang chưa tải xong hoặc không phải trang này. */
  function mine() {
    if (!all('a[href*="/my_"]').length) return -1;
    const main = document.querySelector('[role="main"]'), t = main ? text(main) : "";
    if (!t) return -1;
    if (/Không có bài viết nào để hiển thị|No posts to show/i.test(t)) return 0;
    return Math.max(1, all('[role="article"]', main).length);
  }

  /* Tìm bài vừa đăng theo một đoạn chữ của nó rồi cuộn lên đầu màn hình, để ảnh chụp thấy đúng bài đó */
  function showPost(snippet) {
    const want = letters(snippet).slice(0, 40);
    if (!want) return false;
    const post = all('[role="article"]').find(a => vis(a) && letters(text(a)).includes(want));
    if (!post) return false;
    post.scrollIntoView({ block: "start" });
    window.scrollBy(0, -90);  // chừa chỗ cho thanh đầu trang của Facebook
    return true;
  }

  /* Mỗi nhóm có vài link (ảnh, tên, nút "Xem nhóm"): lấy chữ của link mang tên nhóm */
  function joined() {
    const skip = new Set(["joins", "feed", "discover", "create", "notifications", "search"]);
    const out = new Map();
    for (const a of all('[role="main"] a[href*="/groups/"]')) {
      const m = a.href.match(/\/groups\/([^/?#]+)\/?(?:[?#].*)?$/);
      if (!m || skip.has(m[1])) continue;
      const t = (a.innerText || "").trim().split("\n")[0];
      const name = t && !/^(Xem nhóm|View group)$/i.test(t) ? t : "";
      if (!out.has(m[1]) || (name && !out.get(m[1]))) out.set(m[1], name);
    }
    return [...out].map(([id, name]) => ({ id, name }));
  }

  window.__amkt = {
    hasTrigger: kind => !!trigger(kind),
    open: kind => press(trigger(kind)),
    hasDialog: kind => !!dialog(kind),
    dialogGone: kind => !dialog(kind),
    type, filesReset, filesPush, filesDone, attach, aiLabelOff, audiencePublic, cancel, dismiss, pending, mine, showPost, joined,
    publishState: kind => { const b = publishBtn(kind); return { found: !!b, disabled: b?.getAttribute("aria-disabled") === "true" }; },
    publish: kind => press(publishBtn(kind)),
    /* Khung soạn đang có gì, để báo lại khi soạn thử */
    summary: kind => {
      const d = dialog(kind), box = d?.querySelector('[role="textbox"]');
      return { chars: box ? text(box).length : 0, ready: publishBtn(kind)?.getAttribute("aria-disabled") !== "true" };
    },
    blocked: () => { const t = document.body.innerText; return BLOCKED.find(p => t.includes(p)) || null; },
    canJoin: () => all('[role="main"] [role="button"]').some(b => vis(b) && /Tham gia nhóm|Join group/i.test(text(b))),
    scroll: dy => dy ? window.scrollBy(0, dy) : window.scrollTo(0, 0),
    /* Facebook nhúng tên tài khoản đang dùng vào mã trang (CurrentUserInitialData) */
    name: () => { const m = document.documentElement.innerHTML.match(/"NAME":("(?:[^"\\]|\\.)*")/); return m ? JSON.parse(m[1]) : ""; },
    /* Các nút đang thấy, để dò khi Facebook / Threads đổi giao diện */
    buttons: () => [...new Set(all('[role="main"] [role="button"], [role="button"][aria-label]').filter(vis)
      .map(b => (b.getAttribute("aria-label") || text(b)).slice(0, 40).replace(/\s+/g, " ")).filter(Boolean))].slice(0, 25).join(" · "),
  };
})();
