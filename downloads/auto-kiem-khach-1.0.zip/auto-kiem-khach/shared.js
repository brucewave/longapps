// Defaults and helpers shared by the dashboard, background and content scripts.
const DEFAULT_SETTINGS = {
  groups: [],
  keywords: [
    'build pc', 'build máy', 'build bộ', 'lắp pc', 'lắp máy', 'ráp pc', 'ráp máy',
    'cấu hình pc', 'tư vấn cấu hình', 'nhờ tư vấn pc', 'bp pc',
    'ai bán pc', 'ai bán máy tính', 'mua pc', 'mua máy tính', 'tìm chỗ build',
  ],
  message:
    'Chào anh/chị, bên em là [tên cửa hàng], thấy anh/chị có nhu cầu build PC trong group. Không biết anh/chị đã tìm được chỗ build chưa ạ?',
  postsPerGroup: 30,
  runMinutes: 30,
  gapMinSec: 60,
  gapMaxSec: 120,
  maxMessagesPerRun: 10,
  dryRun: true,
};

async function getSettings() {
  const { settings } = await chrome.storage.local.get('settings');
  const s = { ...DEFAULT_SETTINGS, ...settings };
  // Older versions stored groups as plain links.
  s.groups = s.groups.map((g) => (typeof g === 'string' ? { url: g, name: '', selected: true } : g));
  return s;
}

function normalizeGroupUrl(raw) {
  const m = String(raw).trim().match(/^(?:https?:\/\/)?(?:www\.|m\.|web\.)?facebook\.com\/groups\/([^/?#\s]+)/i);
  return m ? `https://www.facebook.com/groups/${m[1]}` : null;
}

const normalizeText = (s) =>
  s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/đ/g, 'd').replace(/\s+/g, ' ');
