// Runs on facebook.com in three roles:
// - runner: in the scanning window, reads up to N posts of the group and handles matching posts
// - chat: in a Messenger window, attaches the screenshot, types and sends the message
// - collector: on "groups you joined", lists the groups for the dashboard
const rand = (min, max) => Math.floor(min + Math.random() * (max - min + 1));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const pause = (min, max) => sleep(rand(min, max));
const bg = (msg) => chrome.runtime.sendMessage(msg);
const log = (msg, data, level = 'info') => bg({ type: 'log', level, msg, data });

async function waitFor(selector, timeoutMs) {
  const end = Date.now() + timeoutMs;
  while (Date.now() < end) {
    const el = document.querySelector(selector);
    if (el) return el;
    await sleep(500);
  }
  return null;
}

// Small on-page box so whoever is watching can see what the tool is doing.
function status(text) {
  let box = document.getElementById('akk-status');
  if (!box) {
    box = document.createElement('div');
    box.id = 'akk-status';
    box.style.cssText =
      'position:fixed;bottom:16px;left:16px;z-index:99999;max-width:380px;padding:12px 14px;border-radius:10px;' +
      'background:#0f172a;color:#f8fafc;font:13px/1.45 system-ui,sans-serif;box-shadow:0 6px 20px rgba(0,0,0,.35);' +
      'white-space:pre-wrap;border-left:4px solid #2563eb';
    document.body.appendChild(box);
  }
  box.textContent = `Auto Kiếm Khách\n${text}`;
}

// ---------- Runner ----------

async function scrollLikeHuman() {
  for (let i = rand(3, 6); i > 0; i--) {
    window.scrollBy({ top: rand(250, 550), behavior: 'smooth' });
    await pause(400, 1000);
  }
  if (Math.random() < 0.3) await pause(2500, 6000); // stop to "read"
  if (Math.random() < 0.15) window.scrollBy({ top: -rand(150, 400), behavior: 'smooth' });
  await pause(800, 2000);
}

async function expandSeeMore() {
  const buttons = [...document.querySelectorAll('div[role="feed"] div[role="button"]')].filter((b) =>
    /^(Xem thêm|See more)$/.test(b.innerText.trim())
  );
  for (const b of buttons.slice(0, 5)) {
    b.click();
    await pause(300, 800);
  }
}

// Facebook fills in the post's permalink only when the timestamp link is hovered/focused.
function findPostUrl(post) {
  const pick = () =>
    [...post.querySelectorAll('a[href]')].find((a) => /\/groups\/[^/]+\/(posts|permalink)\/\d+/.test(a.href));
  let link = pick();
  if (!link) {
    for (const a of post.querySelectorAll('a[role="link"]')) {
      a.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
      a.dispatchEvent(new FocusEvent('focusin', { bubbles: true }));
    }
    link = pick();
  }
  return link ? link.href.split('?')[0] : null;
}

function readVisiblePosts() {
  const out = [];
  for (const post of document.querySelectorAll('div[role="feed"] > div')) {
    const authorLink = [...post.querySelectorAll('a[href]')].find(
      (a) => /\/groups\/[^/]+\/user\/\d+/.test(a.href) && a.innerText.trim()
    );
    if (!authorLink) continue;
    const message = post.querySelector('[data-ad-rendering-role="story_message"], [data-ad-preview="message"]');
    const postUrl = findPostUrl(post);
    out.push({
      el: post,
      userId: authorLink.href.match(/\/user\/(\d+)/)[1],
      name: authorLink.innerText.trim(),
      postUrl,
      text: (message ? message.innerText : '').trim(),
    });
  }
  return out;
}

// Bring the post to the middle of the screen and screenshot just that post.
async function capturePost(el) {
  el.scrollIntoView({ block: 'center', behavior: 'smooth' });
  await pause(1500, 2500);
  const box = document.getElementById('akk-status');
  if (box) box.style.visibility = 'hidden';
  await sleep(150);
  const r = el.getBoundingClientRect();
  const rect = {
    x: Math.max(0, r.left),
    y: Math.max(0, r.top),
    width: Math.min(r.right, innerWidth) - Math.max(0, r.left),
    height: Math.min(r.bottom, innerHeight) - Math.max(0, r.top),
  };
  try {
    return (await bg({ type: 'capture', rect, dpr: devicePixelRatio }))?.image || null;
  } finally {
    if (box) box.style.visibility = '';
  }
}

const running = async () => (await bg({ type: 'isRunning' }))?.running;

// Wait until the gap since the last message has passed, showing a countdown.
async function waitForTurn(deadline) {
  for (;;) {
    const turn = await bg({ type: 'sendTurn' });
    if (turn.stop || turn.limit) return turn;
    if (turn.waitMs <= 0) return turn;
    if (Date.now() + turn.waitMs > deadline) return { timeout: true };
    status(`Thấy khách, chờ ${Math.ceil(turn.waitMs / 1000)}s nữa mới nhắn (giãn cách giữa 2 tin)...`);
    await sleep(Math.min(turn.waitMs, 1000));
    if (!(await running())) return { stop: true };
  }
}

async function handleLead(p, keyword, settings, deadline, counters) {
  const { skip } = await bg({ type: 'checkLead', userId: p.userId });
  if (skip) {
    await log(`Bỏ qua ${p.name}: ${skip}`);
    return;
  }
  status(`Thấy khách: ${p.name}\nĐang chụp bài...`);
  const image = await capturePost(p.el).catch(() => null);
  const lead = { name: p.name, userId: p.userId, postUrl: p.postUrl, text: p.text.slice(0, 500), keyword, image };
  counters.leads++;

  if (settings.dryRun) {
    await bg({ type: 'addLead', lead: { ...lead, status: 'dry' } });
    await log(`[Chạy thử] Khách: ${p.name}`);
    return;
  }
  const turn = await waitForTurn(deadline);
  if (turn.stop) return;
  if (turn.limit || turn.timeout) {
    await bg({ type: 'addLead', lead: { ...lead, status: turn.limit ? 'limit' : 'timeout' } });
    await log(`Không nhắn ${p.name}: ${turn.limit ? 'đã đủ số tin tối đa' : 'hết thời gian chạy'}`);
    return;
  }

  status(`Đang mở cửa sổ chat với ${p.name}...`);
  const text = settings.message.replaceAll('{ten}', p.name);
  const res = await bg({ type: 'send', lead, text });
  if (res?.ok) {
    counters.sent++;
    await bg({ type: 'addLead', lead: { ...lead, status: 'sent', message: text } });
    await log(`Đã nhắn ${p.name}`);
  } else {
    await bg({ type: 'addLead', lead: { ...lead, status: 'failed', error: res?.error || 'Không rõ lỗi' } });
    await log(`Lỗi khi nhắn ${p.name}: ${res?.error}`, res?.debug, 'error');
  }
}

async function runGroup({ run, group, settings }) {
  const keywords = settings.keywords.map(normalizeText).filter(Boolean);
  const deadline = run.endAt;
  const label = `Group ${run.index + 1}/${run.groups.length}`;
  status(`${label}: đang tải...`);

  const feed = await waitFor('div[role="feed"]', 30000);
  if (!feed) {
    await log(`Không thấy bài viết trong ${group.url}`, null, 'error');
    return bg({ type: 'groupDone' });
  }
  const name = document.title.replace(/^\(\d+\)\s*/, '').replace(/\s*\|\s*Facebook$/, '').trim();
  await bg({ type: 'groupStats', name, postsRead: 0 });
  await log(`Đang lướt: ${name}`);
  await pause(2000, 4000);

  const myId = (document.cookie.match(/c_user=(\d+)/) || [])[1];
  const seen = new Set();
  const counters = { leads: 0, sent: 0 };
  let idleRounds = 0;

  while (seen.size < settings.postsPerGroup && Date.now() < deadline) {
    if (!(await running())) return;
    await expandSeeMore();
    let fresh = 0;
    for (const p of readVisiblePosts()) {
      const key = p.postUrl || `${p.userId}:${p.text.slice(0, 50)}`;
      if (seen.has(key) || seen.size >= settings.postsPerGroup) continue;
      seen.add(key);
      fresh++;
      const keyword = keywords.find((k) => normalizeText(p.text).includes(k));
      if (keyword && p.userId !== myId) await handleLead(p, keyword, settings, deadline, counters);
      if (!(await running())) return;
    }
    await bg({ type: 'groupStats', postsRead: seen.size });
    const left = Math.max(0, Math.round((deadline - Date.now()) / 60000));
    status(`${label}: ${name}\nĐã đọc ${seen.size}/${settings.postsPerGroup} bài · ${counters.leads} khách · đã nhắn ${counters.sent}\nCòn khoảng ${left} phút`);
    idleRounds = fresh ? 0 : idleRounds + 1;
    if (idleRounds >= 8) {
      await log(`Hết bài mới để đọc trong ${name}`);
      break;
    }
    await scrollLikeHuman();
  }

  await log(`Xong ${name}: đọc ${seen.size} bài, ${counters.leads} khách, nhắn ${counters.sent}`);
  status(`${label}: xong. Chuyển group tiếp theo...`);
  await pause(2000, 4000);
  await bg({ type: 'groupDone' });
}

// ---------- Chat window ----------

const dialogTexts = () => [...document.querySelectorAll('div[role="dialog"]')].map((d) => d.innerText.slice(0, 500));

// Messenger's end-to-end encryption asks for a PIN once per account; a person has to set it up.
const pinDialogShown = () => dialogTexts().some((t) => /\bPIN\b|mã PIN|khôi phục tin nhắn|restore your chat/i.test(t));

// Attach through the composer's own file input; fall back to a paste event on the textbox.
async function attachImage(box, dataUrl) {
  const blob = await (await fetch(dataUrl)).blob();
  const dt = new DataTransfer();
  dt.items.add(new File([blob], 'bai-dang.jpg', { type: blob.type }));

  let input = null;
  for (let node = box; node && !input; node = node.parentElement) {
    input = node.querySelector('input[type="file"]');
  }
  if (input) {
    input.files = dt.files;
    input.dispatchEvent(new Event('change', { bubbles: true }));
  } else {
    box.focus();
    box.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
  }
  await pause(2500, 4000); // let Messenger render the preview / upload
  return input ? 'file-input' : 'paste';
}

async function typeAndSend(text, image) {
  const box = await waitFor('div[role="textbox"][contenteditable="true"]', 25000);
  await pause(1500, 3000);
  if (pinDialogShown()) {
    return {
      ok: false,
      error: 'Messenger đang đòi mã PIN. Hãy tạo/nhập PIN một lần ở facebook.com/messages rồi chạy lại.',
      debug: { dialogs: dialogTexts() },
    };
  }
  if (!box) {
    return { ok: false, error: 'Không thấy ô nhập tin nhắn', debug: { url: location.href, dialogs: dialogTexts() } };
  }
  if (box.innerText.trim()) {
    // Leftover draft from an earlier failed attempt.
    box.focus();
    document.execCommand('selectAll');
    document.execCommand('delete');
    await pause(300, 600);
  }
  let attachedVia = null;
  if (image) attachedVia = await attachImage(box, image);
  // Attaching moves focus to the image preview; put the caret back in the textbox before typing.
  box.click();
  box.focus();
  await pause(600, 1200);
  for (const ch of text) {
    document.execCommand('insertText', false, ch);
    await sleep(rand(40, 160));
    if (ch === ' ' && Math.random() < 0.08) await pause(300, 900);
  }
  await pause(800, 2000);
  if (box.innerText.trim() !== text.trim()) {
    // A keystroke got lost; replace the whole content with the exact message.
    box.focus();
    document.execCommand('selectAll');
    document.execCommand('insertText', false, text);
    await pause(500, 1000);
  }
  if (box.innerText.trim() !== text.trim()) {
    return { ok: false, error: 'Gõ chữ không vào được ô chat', debug: { typed: box.innerText, attachedVia, dialogs: dialogTexts() } };
  }

  box.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
  await pause(1500, 2500);
  if (box.innerText.trim()) {
    // Enter didn't send; fall back to the send button.
    const btn = document.querySelector(
      '[aria-label="Nhấn Enter để gửi"], [aria-label="Press enter to send"], [aria-label="Gửi"], [aria-label="Send"]'
    );
    if (btn) btn.click();
    await pause(1500, 2500);
  }
  if (box.innerText.trim()) return { ok: false, error: 'Bấm gửi không ăn', debug: { left: box.innerText, attachedVia } };
  await pause(3000, 5000); // give the image upload time to finish before the window closes
  return { ok: true, attachedVia };
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg.type !== 'typeAndSend') return false;
  typeAndSend(msg.text, msg.image)
    .then(reply)
    .catch((e) => reply({ ok: false, error: e.message }));
  return true;
});

// ---------- Collector ----------

const NOT_GROUPS = new Set(['joins', 'feed', 'discover', 'create', 'notifications', 'you', 'search']);

async function collectJoinedGroups() {
  status('Đang quét các group bạn đã tham gia...');
  await sleep(3000);
  const found = new Map();
  let idle = 0;
  while (idle < 5) {
    const before = found.size;
    for (const a of document.querySelectorAll('a[href*="/groups/"]')) {
      const m = a.href.match(/facebook\.com\/groups\/([^/?#]+)\/?(?:[?#]|$)/);
      if (!m || NOT_GROUPS.has(m[1])) continue;
      const name = a.innerText.trim().split('\n')[0];
      if (!name || /^(Xem nhóm|View group)$/i.test(name)) continue;
      if (!found.has(m[1])) found.set(m[1], { url: `https://www.facebook.com/groups/${m[1]}`, name });
    }
    status(`Đang quét các group bạn đã tham gia... ${found.size} group`);
    idle = found.size === before ? idle + 1 : 0;
    window.scrollBy({ top: 1200, behavior: 'smooth' });
    await pause(1200, 2000);
  }
  status(`Xong, tìm thấy ${found.size} group. Đang lưu...`);
  await bg({ type: 'joinedGroups', groups: [...found.values()] });
}

(async () => {
  const me = await bg({ type: 'whoAmI' });
  if (me?.role === 'collector' && location.pathname.startsWith('/groups/joins')) {
    collectJoinedGroups().catch((e) => log(`Lỗi quét group: ${e.message}`, null, 'error'));
  } else if (me?.role === 'runner' && location.pathname.startsWith('/groups/')) {
    runGroup(me).catch((e) => log(`Lỗi: ${e.message}`, e.stack, 'error'));
  }
})();
