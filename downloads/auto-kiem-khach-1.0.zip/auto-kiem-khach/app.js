// Dashboard: pick groups, set keywords/message/limits, start or stop a run, watch progress, read reports.
const $ = (id) => document.getElementById(id);
const store = chrome.storage.local;
const NUMBER_FIELDS = ['postsPerGroup', 'runMinutes', 'gapMinSec', 'gapMaxSec', 'maxMessagesPerRun'];

const STATUS_LABEL = {
  sent: 'Đã nhắn',
  failed: 'Lỗi',
  dry: 'Chạy thử',
  limit: 'Vượt số tin tối đa',
  timeout: 'Hết giờ',
  running: 'Đang chạy',
  done: 'Hoàn thành',
  stopped: 'Đã dừng',
};

const esc = (s) =>
  String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const fmtTime = (t) => new Date(t).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
const fmtDateTime = (t) =>
  new Date(t).toLocaleString('vi-VN', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit', year: 'numeric' });
const fmtDuration = (ms) => {
  const m = Math.round(ms / 60000);
  return m < 60 ? `${m} phút` : `${Math.floor(m / 60)} giờ ${m % 60} phút`;
};

let settings;

// ---------- Tabs ----------

function showTab(name) {
  for (const b of document.querySelectorAll('.tabs button')) b.setAttribute('aria-selected', String(b.dataset.tab === name));
  $('tab-run').hidden = name !== 'run';
  $('tab-report').hidden = name !== 'report';
  if (name === 'report') renderReports();
}
for (const b of document.querySelectorAll('.tabs button')) b.onclick = () => {
  history.replaceState(null, '', b.dataset.tab === 'report' ? '#report' : '#');
  showTab(b.dataset.tab);
};

// ---------- Settings form ----------

async function saveSettings() {
  await store.set({ settings });
}

function readForm() {
  settings.keywords = $('keywords').value.split('\n').map((k) => k.trim()).filter(Boolean);
  settings.message = $('message').value.trim();
  for (const f of NUMBER_FIELDS) settings[f] = Math.max(1, Number($(f).value) || DEFAULT_SETTINGS[f]);
  if (settings.gapMaxSec < settings.gapMinSec) settings.gapMaxSec = settings.gapMinSec;
  settings.dryRun = $('dryRun').checked;
}

function fillForm() {
  $('keywords').value = settings.keywords.join('\n');
  $('message').value = settings.message;
  for (const f of NUMBER_FIELDS) $(f).value = settings[f];
  $('dryRun').checked = settings.dryRun;
  renderGroups();
}

for (const el of document.querySelectorAll('#keywords, #message, #dryRun, .fields input')) {
  el.addEventListener('change', () => {
    readForm();
    saveSettings();
    renderSummaries();
  });
}

// ---------- Groups ----------

// Groups currently shown in the list (search + "only selected"), with their index in settings.groups.
function visibleGroups() {
  const words = normalizeText($('groupSearch').value.trim()).split(' ').filter(Boolean);
  const onlySelected = $('onlySelected').checked;
  return settings.groups
    .map((g, i) => ({ g, i }))
    .filter(({ g }) => {
      if (onlySelected && !g.selected) return false;
      const hay = normalizeText(`${g.name} ${g.url}`);
      return words.every((w) => hay.includes(w));
    });
}

function renderGroups() {
  const list = $('groupList');
  const selected = settings.groups.filter((g) => g.selected).length;
  $('groupCount').textContent = `${selected}/${settings.groups.length} đã chọn`;
  const shown = visibleGroups();
  const filtered = shown.length !== settings.groups.length;
  $('selectAllLabel').textContent = filtered ? `Chọn tất cả ${shown.length} group đang hiện` : 'Chọn tất cả';
  $('selectAll').checked = shown.length > 0 && shown.every(({ g }) => g.selected);
  renderSummaries();
  if (!settings.groups.length) {
    list.innerHTML = '<li class="empty">Chưa có group. Bấm "Quét group đã tham gia" hoặc dán link.</li>';
    return;
  }
  if (!shown.length) {
    list.innerHTML = '<li class="empty">Không có group nào khớp.</li>';
    return;
  }
  list.innerHTML = shown
    .map(
      ({ g, i }) => `
      <li class="${g.selected ? 'on' : ''}">
        <input type="checkbox" data-i="${i}" ${g.selected ? 'checked' : ''} aria-label="Chọn ${esc(g.name || g.url)}">
        <div class="g-text">
          <div class="g-name">${esc(g.name || 'Chưa rõ tên (sẽ lấy khi chạy)')}</div>
          <a class="g-url" href="${esc(g.url)}" target="_blank" rel="noopener">${esc(g.url.replace('https://www.', ''))}</a>
        </div>
        <button class="remove" data-remove="${i}" title="Xóa group" aria-label="Xóa group">×</button>
      </li>`
    )
    .join('');
}

$('groupList').addEventListener('change', (e) => {
  const i = e.target.dataset.i;
  if (i === undefined) return;
  settings.groups[i].selected = e.target.checked;
  saveSettings();
  renderGroups();
});
$('groupList').addEventListener('click', (e) => {
  const i = e.target.dataset.remove;
  if (i === undefined) return;
  settings.groups.splice(Number(i), 1);
  saveSettings();
  renderGroups();
});
$('selectAll').onchange = (e) => {
  for (const { g } of visibleGroups()) g.selected = e.target.checked;
  saveSettings();
  renderGroups();
};
$('groupSearch').oninput = renderGroups;
$('onlySelected').onchange = renderGroups;

// One-line summaries shown on the headers, useful when the sections are collapsed in the popup.
function renderSummaries() {
  $('kwCount').textContent = `${settings.keywords.length} từ khóa`;
  $('runSummary').textContent = `${settings.postsPerGroup} bài/group · ${settings.runMinutes} phút${settings.dryRun ? ' · chạy thử' : ''}`;
}
$('addGroups').onclick = () => {
  const lines = $('groupLinks').value.split(/\s+/).filter(Boolean);
  const bad = [];
  for (const line of lines) {
    const url = normalizeGroupUrl(line);
    if (!url) bad.push(line);
    else if (!settings.groups.some((g) => g.url === url)) settings.groups.push({ url, name: '', selected: true });
  }
  $('groupLinks').value = bad.join('\n');
  $('runError').textContent = bad.length ? `Không phải link group: ${bad.join(', ')}` : '';
  saveSettings();
  renderGroups();
};
$('scanGroups').onclick = async () => {
  $('scanGroups').disabled = true;
  $('scanGroups').textContent = 'Đang quét...';
  await chrome.runtime.sendMessage({ type: 'scanJoinedGroups' });
};

// ---------- Run controls + live progress ----------

$('startStop').onclick = async () => {
  const { run } = await store.get('run');
  $('runError').textContent = '';
  if (run) {
    await chrome.runtime.sendMessage({ type: 'stop' });
    return;
  }
  readForm();
  await saveSettings();
  if (!settings.dryRun && !confirm(`Chạy thật: tool sẽ gửi tối đa ${settings.maxMessagesPerRun} tin. Tiếp tục?`)) return;
  const res = await chrome.runtime.sendMessage({ type: 'start' });
  if (!res?.ok) $('runError').textContent = res?.error || 'Không bắt đầu được.';
};

async function renderLive() {
  const { run, events = [] } = await store.get(['run', 'events']);
  const pill = $('runPill');
  pill.classList.toggle('running', !!run);
  pill.textContent = run ? (run.dryRun ? 'Đang chạy thử' : 'Đang chạy') : 'Sẵn sàng';
  $('startStop').textContent = run ? 'Dừng' : 'Bắt đầu chạy';
  $('startStop').classList.toggle('danger', !!run);
  $('startStop').classList.toggle('primary', !run);

  if (run) {
    const report = (await store.get(`report:${run.id}`))[`report:${run.id}`];
    const leads = report?.leads || [];
    $('sPosts').textContent = report ? report.groups.reduce((n, g) => n + g.postsRead, 0) : 0;
    $('sLeads').textContent = leads.length;
    $('sSent').textContent = leads.filter((l) => l.status === 'sent').length;
    const left = Math.max(0, run.endAt - Date.now());
    $('sLeft').textContent = `${Math.ceil(left / 60000)}′`;
    $('timeBar').style.width = `${Math.min(100, ((Date.now() - run.startedAt) / (run.endAt - run.startedAt)) * 100)}%`;
    const g = report?.groups[run.index];
    $('liveGroup').textContent = g ? `Group ${run.index + 1}/${run.groups.length}: ${g.name || g.url}` : '';
  } else {
    $('liveGroup').textContent = '';
    $('sLeft').textContent = '--';
    $('timeBar').style.width = '0';
  }

  $('events').innerHTML = events.length
    ? events
        .map((e) => `<li class="${e.level === 'error' ? 'error' : ''}"><time>${fmtTime(e.t)}</time><span>${esc(e.msg)}</span></li>`)
        .join('')
    : '<li class="empty">Chưa có hoạt động. Bấm "Bắt đầu chạy" để tool đi lướt group.</li>';
}

// ---------- Reports ----------

let currentReportId = null;

async function renderReports() {
  const { reports = [] } = await store.get('reports');
  const hashId = (location.hash.match(/report=(\d+)/) || [])[1];
  if (hashId) currentReportId = hashId;
  if (!currentReportId || !reports.some((r) => r.id === currentReportId)) currentReportId = reports[0]?.id || null;

  $('runList').innerHTML = reports.length
    ? reports
        .map(
          (r) => `
        <li><button data-id="${r.id}" class="${r.id === currentReportId ? 'active' : ''}">
          <div class="r-title"><span>${fmtDateTime(r.startedAt)}</span><span class="badge ${r.status}">${STATUS_LABEL[r.status]}</span></div>
          <div class="r-sub">${r.groups} group · ${r.postsRead} bài · ${r.leads} khách · ${r.sent} đã nhắn${r.dryRun ? ' · chạy thử' : ''}</div>
        </button></li>`
        )
        .join('')
    : '<li class="muted" style="padding:10px">Chưa có lần chạy nào.</li>';

  const detail = $('reportDetail');
  if (!currentReportId) {
    detail.innerHTML = '<div class="card empty-state">Chạy tool một lần để xem báo cáo ở đây.</div>';
    return;
  }
  const report = (await store.get(`report:${currentReportId}`))[`report:${currentReportId}`];
  if (!report) return;
  const leads = report.leads;
  const count = (s) => leads.filter((l) => l.status === s).length;
  const duration = (report.endedAt || Date.now()) - report.startedAt;

  detail.innerHTML = `
    <div class="card">
      <div class="card-head report-head">
        <div>
          <h2>Lần chạy ${fmtDateTime(report.startedAt)} <span class="badge ${report.status}">${STATUS_LABEL[report.status]}</span></h2>
          <p>${report.dryRun ? 'Chạy thử (không gửi tin)' : 'Chạy thật'} · ${report.settings.postsPerGroup} bài/group · giới hạn ${report.settings.runMinutes} phút · tối đa ${report.settings.maxMessagesPerRun} tin</p>
        </div>
        <div class="actions">
          <button class="btn small" id="exportCsv">Xuất CSV</button>
          <button class="btn small" id="deleteReport">Xóa</button>
        </div>
      </div>
      <div class="stats five">
        <div class="stat"><span class="num">${fmtDuration(duration)}</span><span class="lbl">Thời gian chạy</span></div>
        <div class="stat"><span class="num">${report.groups.reduce((n, g) => n + g.postsRead, 0)}</span><span class="lbl">Bài đã đọc</span></div>
        <div class="stat"><span class="num">${leads.length}</span><span class="lbl">Khách tìm thấy</span></div>
        <div class="stat"><span class="num ok">${count('sent')}</span><span class="lbl">Đã nhắn</span></div>
        <div class="stat"><span class="num ${count('failed') ? 'bad' : ''}">${count('failed')}</span><span class="lbl">Lỗi</span></div>
      </div>
    </div>

    <div class="card">
      <div class="card-head"><h2>Theo group</h2></div>
      <div class="table-wrap"><table>
        <thead><tr><th>Group</th><th class="num">Bài đã đọc</th><th class="num">Khách</th><th class="num">Đã nhắn</th><th>Trạng thái</th></tr></thead>
        <tbody>${report.groups
          .map(
            (g) => `<tr>
              <td><a href="${esc(g.url)}" target="_blank" rel="noopener">${esc(g.name || g.url)}</a></td>
              <td class="num">${g.postsRead}</td><td class="num">${g.leads}</td><td class="num">${g.sent}</td>
              <td>${g.done ? '<span class="badge done">Xong</span>' : '<span class="badge dry">Chưa lướt hết</span>'}</td>
            </tr>`
          )
          .join('')}</tbody>
      </table></div>
    </div>

    <div class="card">
      <div class="card-head"><h2>Khách tìm thấy</h2><span class="muted">${leads.length} người</span></div>
      ${
        leads.length
          ? `<div class="leads">${leads
              .map(
                (l, i) => `
            <div class="lead">
              ${l.image ? `<button class="thumb" data-img="${i}" aria-label="Xem ảnh bài của ${esc(l.name)}"><img src="${l.image}" alt=""></button>` : '<div class="thumb none">Không có ảnh</div>'}
              <div>
                <div class="l-top">
                  <a class="l-name" href="https://www.facebook.com/${esc(l.userId)}" target="_blank" rel="noopener">${esc(l.name)}</a>
                  <span class="badge ${l.status}">${STATUS_LABEL[l.status]}</span>
                  <span class="kw">${esc(l.keyword)}</span>
                </div>
                <div class="l-meta">${esc(l.groupName || '')} · ${fmtTime(l.at)}</div>
                <p class="l-text">${esc(l.text || '(bài không có chữ)')}</p>
                ${l.error ? `<div class="l-err">${esc(l.error)}</div>` : ''}
                <div class="l-links">
                  ${l.postUrl ? `<a href="${esc(l.postUrl)}" target="_blank" rel="noopener">Xem bài viết</a>` : ''}
                  <a href="https://www.facebook.com/messages/t/${esc(l.userId)}" target="_blank" rel="noopener">Mở Messenger</a>
                </div>
              </div>
            </div>`
              )
              .join('')}</div>`
          : '<div class="empty-state">Lần chạy này chưa tìm thấy khách nào khớp từ khóa.</div>'
      }
    </div>`;

  $('exportCsv').onclick = () => exportCsv(report);
  $('deleteReport').onclick = async () => {
    if (!confirm('Xóa báo cáo này?')) return;
    const { reports: all = [] } = await store.get('reports');
    await store.remove(`report:${report.id}`);
    await store.set({ reports: all.filter((r) => r.id !== report.id) });
    currentReportId = null;
    history.replaceState(null, '', '#report');
    renderReports();
  };
  for (const btn of detail.querySelectorAll('[data-img]')) {
    btn.onclick = () => {
      $('imgDialog').querySelector('img').src = leads[btn.dataset.img].image;
      $('imgDialog').showModal();
    };
  }
}

$('runList').addEventListener('click', (e) => {
  const btn = e.target.closest('button[data-id]');
  if (!btn) return;
  currentReportId = btn.dataset.id;
  history.replaceState(null, '', `#report=${currentReportId}`);
  renderReports();
});

function exportCsv(report) {
  const rows = [['Thời gian', 'Tên', 'Link profile', 'Group', 'Từ khóa', 'Nội dung bài', 'Link bài', 'Trạng thái', 'Lỗi']];
  for (const l of report.leads) {
    rows.push([
      fmtDateTime(l.at), l.name, `https://www.facebook.com/${l.userId}`, l.groupName, l.keyword,
      l.text, l.postUrl || '', STATUS_LABEL[l.status], l.error || '',
    ]);
  }
  const csv = rows.map((r) => r.map((c) => `"${String(c ?? '').replace(/"/g, '""')}"`).join(',')).join('\r\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' }));
  a.download = `bao-cao-${new Date(report.startedAt).toLocaleDateString('sv-SE')}-${report.id}.csv`;
  a.click();
  URL.revokeObjectURL(a.href);
}

// ---------- Live updates ----------

chrome.storage.onChanged.addListener(async (changes) => {
  if (changes.settings) {
    settings = await getSettings();
    // Only the group list changes from outside (scan, names learned during a run).
    renderGroups();
    $('scanGroups').disabled = false;
    $('scanGroups').textContent = 'Quét group đã tham gia';
  }
  if (changes.run || changes.events || Object.keys(changes).some((k) => k.startsWith('report:'))) renderLive();
  if (changes.reports && !$('tab-report').hidden) renderReports();
});
setInterval(renderLive, 5000); // keep the countdown moving
// The background opens "#report=<id>" here when a run ends.
window.addEventListener('hashchange', () => showTab(location.hash.startsWith('#report') ? 'report' : 'run'));

// Opened from the toolbar icon: compact layout with settings sections collapsed.
const isPopup =
  new URLSearchParams(location.search).has('popup') ||
  (chrome.extension?.getViews?.({ type: 'popup' }) || []).includes(window);
if (isPopup) {
  document.body.classList.add('popup');
  $('runSettings').open = false;
  $('cardText').open = false;
}
$('openFull').onclick = async () => {
  await chrome.tabs.create({ url: chrome.runtime.getURL(`app.html${location.hash}`) });
  window.close();
};

(async () => {
  settings = await getSettings();
  fillForm();
  renderLive();
  showTab(location.hash.startsWith('#report') ? 'report' : 'run');
})();
