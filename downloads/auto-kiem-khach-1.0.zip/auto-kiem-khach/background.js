// Coordinates a run: opens the scanning window, walks through the selected groups, opens a small
// chat window per lead, keeps the report up to date, and forwards logs to the local log server
// (npm run logs) for debugging.
importScripts('shared.js');

const LOG_URL = 'http://localhost:3939/log';
const DASHBOARD = chrome.runtime.getURL('app.html');
const rand = (min, max) => Math.floor(min + Math.random() * (max - min + 1));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function log(level, msg, data) {
  console.log(`[${level}] ${msg}`, data ?? '');
  if (level !== 'debug') {
    const { events = [] } = await chrome.storage.local.get('events');
    events.unshift({ t: Date.now(), level, msg });
    await chrome.storage.local.set({ events: events.slice(0, 40) });
  }
  try {
    await fetch(LOG_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ t: new Date().toISOString(), level, msg, data }),
    });
  } catch {
    // Log server not running; console is enough.
  }
}

function waitForTabComplete(tabId) {
  return new Promise((resolve) => {
    const listener = (id, info) => {
      if (id === tabId && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function blobToDataUrl(blob) {
  const bytes = new Uint8Array(await blob.arrayBuffer());
  let bin = '';
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return `data:${blob.type};base64,${btoa(bin)}`;
}

// Screenshot the visible tab and crop it to the post's rectangle (CSS pixels).
async function capturePost(tab, rect, dpr) {
  const shot = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
  const bitmap = await createImageBitmap(await (await fetch(shot)).blob());
  const sx = Math.max(0, Math.round(rect.x * dpr));
  const sy = Math.max(0, Math.round(rect.y * dpr));
  const sw = Math.min(bitmap.width - sx, Math.round(rect.width * dpr));
  const sh = Math.min(bitmap.height - sy, Math.round(rect.height * dpr));
  const canvas = new OffscreenCanvas(sw, sh);
  canvas.getContext('2d').drawImage(bitmap, sx, sy, sw, sh, 0, 0, sw, sh);
  return blobToDataUrl(await canvas.convertToBlob({ type: 'image/jpeg', quality: 0.85 }));
}

async function openDashboard(hash = '') {
  const [tab] = await chrome.tabs.query({ url: `${DASHBOARD}*` });
  const url = `${DASHBOARD}${hash}`;
  if (tab) {
    await chrome.tabs.update(tab.id, { active: true, url });
    await chrome.windows.update(tab.windowId, { focused: true });
  } else {
    await chrome.tabs.create({ url });
  }
}

// ---------- Run + report storage ----------

const getRun = async () => (await chrome.storage.local.get('run')).run || null;
const setRun = (run) => chrome.storage.local.set({ run });
const reportKey = (id) => `report:${id}`;
const getReport = async (id) => (await chrome.storage.local.get(reportKey(id)))[reportKey(id)];

async function saveReport(report) {
  const leads = report.leads;
  const summary = {
    id: report.id,
    startedAt: report.startedAt,
    endedAt: report.endedAt,
    status: report.status,
    dryRun: report.dryRun,
    groups: report.groups.length,
    postsRead: report.groups.reduce((n, g) => n + g.postsRead, 0),
    leads: leads.length,
    sent: leads.filter((l) => l.status === 'sent').length,
    failed: leads.filter((l) => l.status === 'failed').length,
  };
  const { reports = [] } = await chrome.storage.local.get('reports');
  const index = [summary, ...reports.filter((r) => r.id !== report.id)].slice(0, 50);
  await chrome.storage.local.set({ [reportKey(report.id)]: report, reports: index });
}

const groupUrl = (g) => `${g.url}?sorting_setting=CHRONOLOGICAL`;

async function startRun() {
  if (await getRun()) return { ok: false, error: 'Đang có một lần chạy khác.' };
  const s = await getSettings();
  const groups = s.groups.filter((g) => g.selected);
  if (!groups.length) return { ok: false, error: 'Chưa chọn group nào.' };
  if (!s.keywords.length) return { ok: false, error: 'Chưa có từ khóa.' };

  const id = String(Date.now());
  const win = await chrome.windows.create({ url: groupUrl(groups[0]), focused: true, state: 'maximized' });
  const run = {
    id,
    windowId: win.id,
    tabId: win.tabs[0].id,
    groups,
    index: 0,
    startedAt: Date.now(),
    endAt: Date.now() + s.runMinutes * 60000,
    dryRun: s.dryRun,
    sentCount: 0,
    lastSentAt: 0,
    nextGapMs: 0,
  };
  await setRun(run);
  await chrome.storage.local.set({ events: [] });
  await saveReport({
    id,
    startedAt: run.startedAt,
    endedAt: null,
    status: 'running',
    dryRun: s.dryRun,
    settings: { postsPerGroup: s.postsPerGroup, runMinutes: s.runMinutes, maxMessagesPerRun: s.maxMessagesPerRun },
    groups: groups.map((g) => ({ url: g.url, name: g.name, postsRead: 0, leads: 0, sent: 0, done: false })),
    leads: [],
  });
  chrome.alarms.create('runEnd', { when: run.endAt + 3 * 60000 });
  await log('info', `Bắt đầu chạy ${groups.length} group trong ${s.runMinutes} phút${s.dryRun ? ' (chạy thử)' : ''}`);
  return { ok: true };
}

async function finishRun(status) {
  const run = await getRun();
  if (!run) return;
  await chrome.storage.local.remove('run');
  chrome.alarms.clear('runEnd');
  const report = await getReport(run.id);
  if (report) {
    report.endedAt = Date.now();
    report.status = status;
    await saveReport(report);
  }
  const label = { done: 'Đã lướt xong các group', timeout: 'Hết thời gian chạy', stopped: 'Đã dừng' }[status];
  await log('info', `${label}. Xem báo cáo.`);
  await chrome.windows.remove(run.windowId).catch(() => {});
  await openDashboard(`#report=${run.id}`);
}

chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === 'runEnd') finishRun('timeout');
});

chrome.tabs.onRemoved.addListener(async (tabId) => {
  const run = await getRun();
  if (run && run.tabId === tabId) finishRun('stopped');
});

// Open a small chat window, send, then close it.
async function sendInChatWindow(userId, text, image) {
  const win = await chrome.windows.create({
    url: `https://www.facebook.com/messages/t/${userId}`,
    type: 'popup',
    width: 560,
    height: 780,
    focused: true,
  });
  const tabId = win.tabs[0].id;
  try {
    await waitForTabComplete(tabId);
    for (let i = 0; i < 10; i++) {
      try {
        return await chrome.tabs.sendMessage(tabId, { type: 'typeAndSend', text, image });
      } catch {
        await sleep(1000); // content script not registered yet
      }
    }
    return { ok: false, error: 'Không kết nối được cửa sổ chat' };
  } finally {
    await chrome.windows.remove(win.id).catch(() => {});
  }
}

// ---------- Joined-groups scan ----------

async function scanJoinedGroups() {
  const win = await chrome.windows.create({
    url: 'https://www.facebook.com/groups/joins/?nav_source=tab',
    focused: true,
    width: 1000,
    height: 900,
  });
  await chrome.storage.local.set({ collector: { tabId: win.tabs[0].id, windowId: win.id, startedAt: Date.now() } });
  return { ok: true };
}

async function saveJoinedGroups(found) {
  const s = await getSettings();
  const known = new Map(s.groups.map((g) => [g.url, g]));
  let added = 0;
  for (const g of found) {
    const url = normalizeGroupUrl(g.url);
    if (!url) continue;
    if (known.has(url)) {
      if (!known.get(url).name) known.get(url).name = g.name;
    } else {
      known.set(url, { url, name: g.name, selected: false });
      added++;
    }
  }
  await chrome.storage.local.set({ settings: { ...s, groups: [...known.values()] } });
  const { collector } = await chrome.storage.local.get('collector');
  await chrome.storage.local.remove('collector');
  if (collector) await chrome.windows.remove(collector.windowId).catch(() => {});
  await log('info', `Quét được ${found.length} group đã tham gia, thêm mới ${added}`);
  await openDashboard();
  return { ok: true, added };
}

// ---------- Messages from dashboard / content scripts ----------

const handlers = {
  start: startRun,
  async stop() {
    await finishRun('stopped');
    return { ok: true };
  },
  scanJoinedGroups,
  async joinedGroups(msg) {
    return saveJoinedGroups(msg.groups);
  },
  async whoAmI(msg, sender) {
    const tabId = sender.tab?.id;
    const [run, { collector }] = await Promise.all([getRun(), chrome.storage.local.get('collector')]);
    if (collector?.tabId === tabId) return { role: 'collector' };
    if (run?.tabId === tabId) return { role: 'runner', run, group: run.groups[run.index], settings: await getSettings() };
    return { role: null };
  },
  async isRunning() {
    return { running: !!(await getRun()) };
  },
  async groupStats(msg) {
    const run = await getRun();
    if (!run) return { ok: false };
    const report = await getReport(run.id);
    const g = report.groups[run.index];
    if (msg.name) {
      g.name = msg.name;
      // Remember the real group name in settings for pasted links.
      const s = await getSettings();
      const sg = s.groups.find((x) => x.url === g.url);
      if (sg && !sg.name) {
        sg.name = msg.name;
        await chrome.storage.local.set({ settings: s });
      }
    }
    if (msg.postsRead !== undefined) g.postsRead = msg.postsRead;
    await saveReport(report);
    return { ok: true };
  },
  // Why this person should not be contacted, or null.
  async checkLead(msg) {
    const run = await getRun();
    const { sent = {} } = await chrome.storage.local.get('sent');
    if (sent[msg.userId]) return { skip: 'đã nhắn ở lần chạy trước' };
    const report = run && (await getReport(run.id));
    if (report?.leads.some((l) => l.userId === msg.userId)) return { skip: 'đã gặp ở lần chạy này' };
    return { skip: null };
  },
  // How long until the next message may go out, and whether the run's limit is reached.
  async sendTurn() {
    const run = await getRun();
    const s = await getSettings();
    if (!run) return { stop: true };
    if (run.sentCount >= s.maxMessagesPerRun) return { limit: true };
    const waitMs = run.lastSentAt ? Math.max(0, run.lastSentAt + run.nextGapMs - Date.now()) : 0;
    return { waitMs };
  },
  async send(msg) {
    const res = await sendInChatWindow(msg.lead.userId, msg.text, msg.lead.image);
    const run = await getRun();
    if (res?.ok && run) {
      const s = await getSettings();
      run.sentCount++;
      run.lastSentAt = Date.now();
      run.nextGapMs = rand(s.gapMinSec, s.gapMaxSec) * 1000;
      await setRun(run);
      const { sent = {} } = await chrome.storage.local.get('sent');
      sent[msg.lead.userId] = { name: msg.lead.name, at: Date.now() };
      await chrome.storage.local.set({ sent });
    }
    return res;
  },
  async addLead(msg) {
    const run = await getRun();
    if (!run) return { ok: false };
    const report = await getReport(run.id);
    report.leads.push({ ...msg.lead, groupName: report.groups[run.index].name, groupUrl: run.groups[run.index].url, at: Date.now() });
    report.groups[run.index].leads++;
    if (msg.lead.status === 'sent') report.groups[run.index].sent++;
    await saveReport(report);
    return { ok: true };
  },
  async groupDone() {
    const run = await getRun();
    if (!run) return { ok: true };
    const report = await getReport(run.id);
    report.groups[run.index].done = true;
    await saveReport(report);
    run.index++;
    if (run.index >= run.groups.length) {
      await finishRun('done');
      return { ok: true, finished: true };
    }
    if (Date.now() >= run.endAt) {
      await finishRun('timeout');
      return { ok: true, finished: true };
    }
    await setRun(run);
    await log('info', `Chuyển sang group ${run.index + 1}/${run.groups.length}`);
    await chrome.tabs.update(run.tabId, { url: groupUrl(run.groups[run.index]) });
    return { ok: true };
  },
  async log(msg) {
    await log(msg.level, msg.msg, msg.data);
    return { ok: true };
  },
  async capture(msg, sender) {
    return { image: await capturePost(sender.tab, msg.rect, msg.dpr) };
  },
};

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  const handler = handlers[msg.type];
  if (!handler) return false;
  handler(msg, sender)
    .then(reply)
    .catch((e) => reply({ ok: false, error: e.message }));
  return true;
});
